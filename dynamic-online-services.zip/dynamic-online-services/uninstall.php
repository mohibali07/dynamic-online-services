<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following:
 *
 * - This method should be static.
 * - This method should not return anything.
 * - If you need to use a class, you'll need to include it manually.
 *
 * @link       https://developer.wordpress.org/plugins/the-basics/uninstall-methods/
 * @package    Dynamic_Online_Services
 */

declare(strict_types=1);

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

// Check for user capabilities
if (!current_user_can('activate_plugins')) {
	exit;
}

require_once plugin_dir_path(__FILE__) . 'dynamic-online-services.php';

// Execute the final cleanup
\TechmireSolutions\DynamicOnlineServices\Core\Uninstaller::uninstall();
