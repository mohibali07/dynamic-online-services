<?php
/**
 * Shortcode Factory Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

if ( ! \defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ShortcodeManager
 */
class ShortcodeManager {

	/**
	 * Registered shortcodes.
	 *
	 * @var AbstractShortcode[]
	 */
	private $shortcodes = [];

	/**
	 * Register a shortcode.
	 *
	 * @param AbstractShortcode $shortcode Shortcode instance.
	 * @return void
	 */
	public function register( AbstractShortcode $shortcode ): void {
		$this->shortcodes[] = $shortcode;
	}

	/**
	 * Initialize all registered shortcodes.
	 */
	public function boot(): void {
		foreach ( $this->shortcodes as $shortcode ) {
			$shortcode->init();
		}
	}
}
