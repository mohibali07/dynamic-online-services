<?php
/**
 * Abstract Shortcode Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract Class AbstractShortcode
 */
abstract class AbstractShortcode {

	/**
	 * Shortcode tag.
	 *
	 * @var string
	 */
	protected string $tag;

	/**
	 * Initialize the shortcode.
	 */
	public function init(): void {
		add_shortcode( $this->get_tag(), [ $this, 'render_callback' ] );
	}

	/**
	 * Get the shortcode tag.
	 *
	 * @return string
	 */
	abstract public function get_tag(): string;

	/**
	 * Shortcode callback.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public function render_callback( $atts ): string {
		$atts = is_array( $atts ) ? $atts : [];
		return $this->render( $atts );
	}

	/**
	 * Render the shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	abstract public function render( array $atts ): string;
}
