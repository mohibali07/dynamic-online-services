<?php
/**
 * Category Hero Shortcode Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Services\HeroDataService;
use TechmireSolutions\DynamicOnlineServices\Services\StyleService;
use WP_Term;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class CategoryHero
 */
class CategoryHero extends AbstractHeroShortcode
{
	/**
	 * Hero Data Service.
	 *
	 * @var HeroDataService
	 */
	private $data_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsServiceInterface $settings_service Settings service.
	 * @param RendererInterface        $renderer         Renderer.
	 * @param StyleService             $style_service    Style service.
	 * @param HeroDataService          $data_service     Hero data service.
	 */
	public function __construct(
		SettingsServiceInterface $settings_service,
		RendererInterface $renderer,
		StyleService $style_service,
		HeroDataService $data_service
	) {
		parent::__construct($settings_service, $renderer, $style_service);
		$this->data_service = $data_service;
	}

	/**
	 * Get the shortcode tag.
	 *
	 * @return string
	 */
	public function get_tag(): string
	{
		return 'service_category_hero';
	}

	/**
	 * Render the shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function render(array $atts): string
	{
		// Get taxonomy slug from HeroDataService (which gets it from injected CptSettings)
		$taxonomy_slug = $this->data_service->get_taxonomy_slug();

		if (!is_tax($taxonomy_slug)) {
			return '';
		}

		$queried_object = get_queried_object();

		if (!$queried_object instanceof WP_Term) {
			return '';
		}

		// Allow filtering the queried object
		$queried_object = apply_filters('dynos_category_hero_term', $queried_object);

		// Get hero data
		$hero_data = $this->data_service->get_category_hero_data($queried_object);

		// Process and Render
		$output = $this->process_hero($atts, $hero_data);

		// Allow filtering the final output
		return apply_filters('dynos_category_hero_output', $output, $queried_object);
	}
}
