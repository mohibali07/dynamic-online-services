<?php
/**
 * Abstract Hero Shortcode Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Services\StyleService;
use TechmireSolutions\DynamicOnlineServices\Helpers\ShortcodeAttributes;
use TechmireSolutions\DynamicOnlineServices\Styles\HeroStyles;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Abstract Class AbstractHeroShortcode
 */
abstract class AbstractHeroShortcode extends AbstractShortcode
{
	/**
	 * Settings Service.
	 *
	 * @var SettingsServiceInterface
	 */
	protected $settings_service;

	/**
	 * Renderer.
	 *
	 * @var RendererInterface
	 */
	protected $renderer;

	/**
	 * Style Service.
	 *
	 * @var StyleService
	 */
	protected $style_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsServiceInterface $settings_service Settings service.
	 * @param RendererInterface        $renderer         Renderer.
	 * @param StyleService             $style_service    Style service.
	 */
	public function __construct(
		SettingsServiceInterface $settings_service,
		RendererInterface $renderer,
		StyleService $style_service
	) {
		$this->settings_service = $settings_service;
		$this->renderer = $renderer;
		$this->style_service = $style_service;
	}

	/**
	 * Process and render the hero.
	 *
	 * @param array  $atts      Shortcode attributes.
	 * @param array  $hero_data Pre-retrieved hero data.
	 * @return string HTML output.
	 */
	protected function process_hero(array $atts, array $hero_data): string
	{
		// Default height from data or settings
		$default_height = !empty($hero_data['height']) ? $hero_data['height'] : $this->settings_service->get_option('hero_height', '50vh');

		// Parse shortcode attributes
		$atts = ShortcodeAttributes::parse(
			$atts,
			['height' => $default_height],
			$this->get_tag()
		);



		// Validate height
		$atts['height'] = ShortcodeAttributes::validate_hero_height($atts['height'], $default_height);

		// Override height if provided in atts
		if (!empty($atts['height'])) {
			$hero_data['height'] = $atts['height'];
		}

		// Breadcrumbs integration
		$enable_breadcrumbs = $this->settings_service->get_option('rank_math_breadcrumbs', true);
		if ($enable_breadcrumbs && function_exists('rank_math_the_breadcrumbs')) {
			ob_start();
			rank_math_the_breadcrumbs();
			$hero_data['breadcrumbs'] = ob_get_clean();
		} else {
			$hero_data['breadcrumbs'] = '';
		}

		// Enqueue styles via injected service
		$this->style_service->enqueue_hero_styles(
			isset($hero_data['font_family']) ? $hero_data['font_family'] : 'inherit',
			isset($hero_data['overlay_color']) ? $hero_data['overlay_color'] : '#000000'
		);

		// Render
		return $this->renderer->render($hero_data);
	}
}
