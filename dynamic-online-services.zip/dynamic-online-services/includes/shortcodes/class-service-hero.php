<?php
/**
 * Service Hero Shortcode Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Services\HeroDataService;
use TechmireSolutions\DynamicOnlineServices\Services\StyleService;
use WP_Post;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class ServiceHero
 */
class ServiceHero extends AbstractHeroShortcode
{
	/**
	 * Hero Data Service.
	 *
	 * @var HeroDataService
	 */
	private $data_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsServiceInterface $settings_service Settings service.
	 * @param RendererInterface        $renderer         Renderer.
	 * @param StyleService             $style_service    Style service.
	 * @param HeroDataService          $data_service     Hero data service.
	 */
	public function __construct(
		SettingsServiceInterface $settings_service,
		RendererInterface $renderer,
		StyleService $style_service,
		HeroDataService $data_service
	) {
		parent::__construct($settings_service, $renderer, $style_service);
		$this->data_service = $data_service;
	}

	/**
	 * Get the shortcode tag.
	 *
	 * @return string
	 */
	public function get_tag(): string
	{
		return 'single_service_hero';
	}

	/**
	 * Render the shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function render(array $atts): string
	{
		// Get service slug from HeroDataService
		$service_slug = $this->data_service->get_service_slug();

		if (!is_singular($service_slug)) {
			return '';
		}

		$post = get_queried_object();
		if (!$post || !($post instanceof WP_Post)) {
			$post = get_post();
		}

		if (!$post instanceof WP_Post) {
			return '';
		}

		// Get hero data
		$hero_data = $this->data_service->get_service_hero_data($post);

		// Process and Render
		$output = $this->process_hero($atts, $hero_data);

		// Allow filtering the final output
		return apply_filters('dynos_service_hero_output', $output, $post);
	}
}
