<?php
/**
 * Cards Shortcode Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Shortcodes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Shortcodes;

if (!\defined('ABSPATH')) {
	exit;
}

/**
 * Cards class.
 */
class Cards extends AbstractShortcode {

	/**
	 * Shortcode tag.
	 *
	 * @var string
	 */
	const TAG = 'service_cards';

	/**
	 * Alias Shortcode tag.
	 *
	 * @var string
	 */
	const ALIAS_TAG = 'course_cards';

	/**
	 * Get the shortcode tag.
	 *
	 * @return string
	 */
	public function get_tag(): string {
		return self::TAG;
	}

	/**
	 * Initialize shortcode.
	 * Overrides base init to handle alias.
	 */
	public function init(): void {
		parent::init();
		add_shortcode( self::ALIAS_TAG, [ $this, 'render_callback' ] );
	}

	/**
	 * Render shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public function render( array $atts ): string {
		// Get default taxonomy slug
		$validator = new \TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator();
		$settings = $validator->get_settings();
		$default_taxonomy = isset( $settings['taxonomy_slug'] ) ? $settings['taxonomy_slug'] : 'service-category';

		// Parse attributes
		$atts = shortcode_atts(
			[
				'ids'             => '', // specific post IDs (comma separated)
				'category'        => '', // specific category slugs/ids (comma separated)
				'taxonomy'        => $default_taxonomy,
				'orderby'         => 'date',
				'order'           => 'DESC',
				'limit'           => '-1',
				'columns'         => '3', // Default columns
				'min_width'       => '', // Optional override for card min-width
				'show_pagination' => 'false',
				'paged'           => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1,
			],
			$atts,
			self::TAG
		);

		// Enqueue styles
		\TechmireSolutions\DynamicOnlineServices\Styles\CardStyles::enqueue( true );

		return $this->generate_output( $atts );
	}

    /**
     * Renderer instance.
     *
     * @var \TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface
     */
    private $renderer;

    /**
     * Query Service.
     *
     * @var \TechmireSolutions\DynamicOnlineServices\Interfaces\QueryServiceInterface
     */
    private $query_service;

    /**
     * Constructor.
     *
     * @param \TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface|null $renderer Renderer instance.
     * @param \TechmireSolutions\DynamicOnlineServices\Interfaces\QueryServiceInterface|null $query_service Query Service instance.
     */
    public function __construct(
        \TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface $renderer = null,
        \TechmireSolutions\DynamicOnlineServices\Interfaces\QueryServiceInterface $query_service = null
    ) {
        $this->renderer = $renderer ?: new \TechmireSolutions\DynamicOnlineServices\Renderers\CardsRenderer();
        $this->query_service = $query_service ?: new \TechmireSolutions\DynamicOnlineServices\Services\CardsQueryService();
    }

	/**
	 * Generate HTML output.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	protected function generate_output( array $atts ): string {
		// 1. Query Data - use Service
		$query = $this->query_service->get_query( $atts );

		$items = [];
		if ( $query->have_posts() ) {
			// Optimize: Pre-load all post meta to prevent N+1 queries.
			update_meta_cache( 'post', wp_list_pluck( $query->posts, 'ID' ) );

			while ( $query->have_posts() ) {
				$query->the_post();

				// Format data similarly to category items for reuse
				$items[] = [
					'type'        => 'post',
					'id'          => get_the_ID(),
					'title'       => get_the_title(),
					'url'         => get_permalink(),
					'image_url'   => get_the_post_thumbnail_url( get_the_ID(), 'medium_large' ),
					'image_alt'   => get_post_meta( get_post_thumbnail_id(), '_wp_attachment_image_alt', true ),
					'description' => get_the_excerpt(),
				];
			}
			wp_reset_postdata();
		}

		// 2. Render
		if ( empty( $items ) ) {
			return '';
		}

		// Use Injected Renderer
		return $this->renderer->render(
			[
				'items' => $items,
				'atts'  => $atts,
			]
		);
	}
}
