<?php
/**
 * Service Provider Interface
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface ServiceProviderInterface
 */
interface ServiceProviderInterface
{
	/**
	 * Register services with the container.
	 *
	 * @return void
	 */
	public function register(): void;

	/**
	 * Boot services.
	 *
	 * @return void
	 */
	public function boot(): void;
}
