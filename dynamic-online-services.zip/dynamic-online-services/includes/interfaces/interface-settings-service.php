<?php
/**
 * Settings Service Interface
 *
 * Contract for settings service operations.
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface SettingsServiceInterface
 */
interface SettingsServiceInterface
{
	/**
	 * Get a plugin option value.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Default value if option doesn't exist.
	 * @return mixed Option value.
	 */
	public function get_option(string $key, $default = null);

	/**
	 * Register hooks for settings functionality.
	 *
	 * @return void
	 */
	public function register_hooks(): void;
}
