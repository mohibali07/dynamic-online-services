<?php
/**
 * Admin Notice Service Interface
 *
 * Contract for admin notice operations.
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface AdminNoticeServiceInterface
 */
interface AdminNoticeServiceInterface
{
	/**
	 * Display an error notice.
	 *
	 * @param string $message Error message.
	 * @return void
	 */
	public function error(string $message): void;

	/**
	 * Add a validation warning notice.
	 *
	 * @param string $message     User-facing message.
	 * @param string $log_message Debug log message.
	 * @return void
	 */
	public function add_validation_warning(string $message, string $log_message): void;
}
