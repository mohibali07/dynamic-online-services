<?php
/**
 * Service Interface
 *
 * Base contract for all services.
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface ServiceInterface
 */
interface ServiceInterface
{
}
