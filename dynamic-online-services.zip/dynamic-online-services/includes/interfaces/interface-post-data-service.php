<?php
/**
 * Post Data Service Interface
 *
 * Contract for post data operations.
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface PostDataServiceInterface
 */
interface PostDataServiceInterface
{
	/**
	 * Get service banner image.
	 *
	 * @param int $post_id Post ID.
	 * @return array Image data array.
	 */
	public function get_service_banner_image(int $post_id): array;

	/**
	 * Get service description.
	 *
	 * @param int $post_id Post ID.
	 * @return string Service description.
	 */
	public function get_service_description(int $post_id): string;
}
