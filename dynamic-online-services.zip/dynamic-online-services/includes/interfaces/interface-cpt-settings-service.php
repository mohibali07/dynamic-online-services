<?php
/**
 * CPT Settings Service Interface
 *
 * Contract for custom post type settings operations.
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Interface CptSettingsServiceInterface
 */
interface CptSettingsServiceInterface
{
	/**
	 * Get all CPT settings.
	 *
	 * Returns sanitized and validated settings including:
	 * - service_slug
	 * - taxonomy_slug
	 * - menu_position
	 * - menu_icon
	 * - cpt_singular
	 * - cpt_plural
	 * - tax_singular
	 * - tax_plural
	 *
	 * @return array Sanitized settings array.
	 */
	public function get_settings(): array;

	/**
	 * Get service post type slug.
	 *
	 * @return string Service slug.
	 */
	public function get_service_slug(): string;

	/**
	 * Get taxonomy slug.
	 *
	 * @return string Taxonomy slug.
	 */
	public function get_taxonomy_slug(): string;
}
