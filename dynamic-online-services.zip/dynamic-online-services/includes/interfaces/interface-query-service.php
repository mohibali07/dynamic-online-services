<?php
/**
 * Query Service Interface
 *
 * @package Dynamic_Online_Services
 * @subpackage Interfaces
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Interfaces;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interface QueryServiceInterface
 */
interface QueryServiceInterface {
	/**
	 * Get query results.
	 *
	 * @param array $atts Attributes.
	 * @return WP_Query
	 */
	public function get_query( array $atts ): WP_Query;

	/**
	 * Get query arguments.
	 *
	 * @param array $atts Attributes.
	 * @return array
	 */
	public function get_query_args( array $atts ): array;
}
