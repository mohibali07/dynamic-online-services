<?php
/**
 * Settings API Provider Class
 *
 * Responsible for registering settings for the WordPress REST API.
 *
 * @package Dynamic_Online_Services
 * @subpackage Admin
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Admin;

use TechmireSolutions\DynamicOnlineServices\Settings\Defaults;
use TechmireSolutions\DynamicOnlineServices\Settings\Sanitization;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * SettingsApiProvider class.
 *
 * Single responsibility: Register settings for REST API.
 *
 * @since 1.1.3
 */
class SettingsApiProvider
{

	/**
	 * Register settings for REST API.
	 *
	 * @since 1.1.3
	 * @return void
	 */
	public static function register(): void
	{
		// SECURITY FIX: Explicitly whitelist only necessary REST API properties
		// Instead of exposing ALL settings with additionalProperties: true,
		// only expose safe, non-sensitive visual styling options
		$rest_schema_properties = [
			// Hero styling
			'hero_title_color'                  => ['type' => 'string'],
			'hero_overlay_color'                => ['type' => 'string'],
			'hero_overlay_opacity'              => ['type' => 'number'],

			// Card styling
			'card_bg_color'                     => ['type' => 'string'],
			'card_title_color'                  => ['type' => 'string'],
			'card_description_color'            => ['type' => 'string'],
			'card_button_bg_color'              => ['type' => 'string'],
			'card_button_text_color'            => ['type' => 'string'],
			'card_button_hover_bg_color'        => ['type' => 'string'],
			'card_button_hover_text_color'      => ['type' => 'string'],
			'card_button_text'                  => ['type' => 'string'],

			// FAQ styling
			'faq_item_border_color'             => ['type' => 'string'],
			'faq_question_bg_color'             => ['type' => 'string'],
			'faq_question_bg_hover'             => ['type' => 'string'],
			'faq_question_text_color'           => ['type' => 'string'],
			'faq_answer_text_color'             => ['type' => 'string'],

			// General Settings
			'service_post_type_slug'            => ['type' => 'string'],
			'service_taxonomy_slug'             => ['type' => 'string'],
			'service_menu_position'             => ['type' => 'integer'],
			'service_menu_icon'                 => ['type' => 'string'],
			'service_cpt_singular_name'         => ['type' => 'string'],
			'service_cpt_plural_name'           => ['type' => 'string'],
			'service_tax_singular_name'         => ['type' => 'string'],
			'service_tax_plural_name'           => ['type' => 'string'],
			'max_grid_columns'                  => ['type' => 'integer'],
			'min_grid_columns'                  => ['type' => 'integer'],
			'max_taxonomy_depth'                => ['type' => 'integer'],
			'default_excerpt_length'            => ['type' => 'integer'],
			'max_posts_per_page'                => ['type' => 'integer'],
			'default_grid_min_width'            => ['type' => 'string'],
			'max_faqs_per_post'                 => ['type' => 'integer'],
			'delete_data_on_uninstall'          => ['type' => 'boolean'],
			'breakpoint_tablet'                 => ['type' => 'string'],
			'breakpoint_mobile'                 => ['type' => 'string'],
		];

		register_setting(
			'Dynamic_Online_Services',
			'dynos_options',
			[
				'type' => 'object',
				'sanitize_callback' => [Sanitization::class, 'sanitize'],
				'default' => Defaults::get_options(),
				'show_in_rest' => [
					'schema' => [
						'type' => 'object',
						'properties' => $rest_schema_properties,
						'additionalProperties' => true, // Allow all settings fields, not just whitelisted ones
					],
				],
			]
		);
	}
}
