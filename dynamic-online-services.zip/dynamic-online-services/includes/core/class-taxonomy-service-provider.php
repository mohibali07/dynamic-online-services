<?php
/**
 * Taxonomy Service Provider
 *
 * Handles registration and bootstrapping of taxonomy-related services.
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use TechmireSolutions\DynamicOnlineServices\Core\Container;
use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Taxonomies\FieldsRenderer;
use TechmireSolutions\DynamicOnlineServices\Taxonomies\FieldsSaver;
use TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Taxonomy Service Provider.
 */
class TaxonomyServiceProvider implements ServiceProviderInterface {

	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void {
		$container = Container::get_instance();

		// FieldsRenderer
		$container->set(
			FieldsRenderer::class,
			function ( $container ) {
				return new FieldsRenderer(
					$container->get( CptSettingsValidator::class )
				);
			},
			true
		);

		// FieldsSaver
		$container->set(
			FieldsSaver::class,
			function ( $container ) {
				return new FieldsSaver(
					$container->get( CptSettingsValidator::class )
				);
			},
			true
		);
	}

	/**
	 * Bootstrap services.
	 *
	 * @return void
	 */
	public function boot(): void {
		$container = Container::get_instance();

		// Get instances and register hooks
		$fields_renderer = $container->get( FieldsRenderer::class );
		$fields_saver    = $container->get( FieldsSaver::class );

		$fields_renderer->register();
		$fields_saver->register();
	}
}
