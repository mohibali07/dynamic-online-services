<?php
/**
 * Block Registrar Class
 *
 * Handles registration of Gutenberg blocks.
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

if (!\defined('ABSPATH')) {
	exit;
}

use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;

/**
 * Class BlockRegistrar
 */
class BlockRegistrar
{
	/**
	 * Admin Notice Service.
	 *
	 * @var AdminNoticeService
	 */
	private $admin_notice_service;

	/**
	 * Constructor.
	 *
	 * @param AdminNoticeService $admin_notice_service
	 */
	public function __construct(AdminNoticeService $admin_notice_service)
	{
		$this->admin_notice_service = $admin_notice_service;
	}

	/**
	 * Register blocks.
	 *
	 * @return void
	 */
	public function register(): void
	{
		try {
			\register_block_type(DYNOS_PLUGIN_DIR . 'build/blocks/service-cards');
		} catch (\Exception $e) {
			$this->admin_notice_service->log_error(
				\sprintf(
					'DYNOS Block Registration Failed: %s',
					$e->getMessage()
				),
				'warning'
			);
		}
	}
}
