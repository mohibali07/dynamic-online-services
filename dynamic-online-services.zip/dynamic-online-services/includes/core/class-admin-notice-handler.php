<?php
/**
 * Admin Notice Handler Class
 *
 * Handles display of admin notices for the plugin core.
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

if (!\defined('ABSPATH')) {
	exit;
}

use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;

/**
 * Class AdminNoticeHandler
 */
class AdminNoticeHandler
{
	/**
	 * Admin Notice Service.
	 *
	 * @var AdminNoticeService
	 */
	private $service;

	/**
	 * Constructor.
	 *
	 * @param AdminNoticeService $service Admin notice service.
	 */
	public function __construct(AdminNoticeService $service)
	{
		$this->service = $service;
	}

	/**
	 * Display activation error notice.
	 *
	 * @return void
	 */
	public function display_activation_errors(): void
	{
		$error_message = \get_transient('dynos_activation_error');
		if ($error_message) {
			\delete_transient('dynos_activation_error');
			$this->service->error((string) $error_message);
		}

		// Display component initialization errors
		$component_error = \get_transient('dynos_component_init_error');
		if ($component_error) {
			\delete_transient('dynos_component_init_error');
			$this->service->error((string) $component_error);
		}
	}
}
