<?php
/**
 * Main Plugin Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

if (!\defined('ABSPATH')) {
    exit;
}

/**
 * Plugin class.
 */
class Plugin
{

    /**
     * Instance.
     *
     * @var Plugin
     */
    private static $instance;

    /**
     * Service Providers.
     *
     * @var array
     */
    private $providers = [];

    /**
     * Get instance.
     *
     * @return Plugin
     */
    public static function get_instance(): Plugin
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct()
    {
        $this->load_dependencies();
        $this->define_hooks();
    }

    /**
     * Load dependencies.
     *
     * @since 1.1.3 Refactored to use DependencyLoader.
     */
    	private function load_dependencies(): void
	{
		DependencyLoader::load();

		// Get container instance
		$container = Container::get_instance();

		// Register Configuration Provider (must be first to define constants)
		$this->register_service_provider(new \TechmireSolutions\DynamicOnlineServices\Providers\ConfigurationServiceProvider($container));

		// Register Data Service Provider (registers all core data services)
		$this->register_service_provider(new \TechmireSolutions\DynamicOnlineServices\Providers\DataServiceProvider($container));

		// Register Shortcode Provider
		$this->register_service_provider(new \TechmireSolutions\DynamicOnlineServices\Providers\ShortcodeServiceProvider($container));

		// Register Core Service Provider (legacy services not yet refactored)
		$this->register_service_provider(new CoreServiceProvider());

		// Register Assets Service Provider
		$this->register_service_provider(new AssetsServiceProvider());

		// Register Settings Service Provider
		$this->register_service_provider(new SettingsServiceProvider());

		// Register Taxonomy Service Provider
		$this->register_service_provider(new TaxonomyServiceProvider());

		// Register Integration Service Provider
		$this->register_service_provider(new IntegrationServiceProvider());
    }

    /**
     * Register a service provider.
     *
     * @param \TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface $provider
     * @return void
     */
    public function register_service_provider(\TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface $provider): void
    {
        $this->providers[] = $provider;
        $provider->register();
    }



    /**
     * Define hooks.
     */
    private function define_hooks(): void
    {
        // Activation/Deactivation hooks are handled in main file

        // Boot providers
        // Boot providers
        add_action('init', [$this, 'boot_providers'], 5);
    }

    /**
     * Boot all registered service providers.
     *
     * @return void
     */
    public function boot_providers(): void
    {
        foreach ($this->providers as $provider) {
            $provider->boot();
        }
    }
}
