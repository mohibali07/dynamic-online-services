<?php
/**
 * Settings Service Provider
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class SettingsServiceProvider
 */
class SettingsServiceProvider implements ServiceProviderInterface
{
	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		$container = Container::get_instance();

		$container->set(
			\TechmireSolutions\DynamicOnlineServices\Services\SettingsService::class,
			function () {
				return new \TechmireSolutions\DynamicOnlineServices\Services\SettingsService();
			},
			true // Shared
		);
	}

	/**
	 * Boot services.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		try {
			SettingsInitializer::init();
		} catch (\Exception $e) {
			// Log error
		}
	}
}
