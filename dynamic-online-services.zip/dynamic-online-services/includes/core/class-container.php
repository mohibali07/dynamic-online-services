<?php
/**
 * Dependency Injection Container
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use Exception;
use ReflectionClass;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class Container
 */
class Container
{
	/**
	 * Services registry.
	 *
	 * @var array
	 */
	private $services = [];

	/**
	 * Shared instances.
	 *
	 * @var array
	 */
	private $instances = [];

	/**
	 * Instance of the container.
	 *
	 * @var Container
	 */
	private static $instance;

	/**
	 * Get container instance (Singleton for global access if absolutely necessary).
	 *
	 * @return Container
	 */
	public static function get_instance(): Container
	{
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Set container instance (for testing).
	 *
	 * @param Container|null $instance Container instance.
	 */
	public static function set_instance(?Container $instance): void
	{
		self::$instance = $instance;
	}

	/**
	 * Set a service.
	 *
	 * @param string $id Service ID or Class Name.
	 * @param callable|object|string $concrete Concrete implementation.
	 * @param bool $shared Whether to share the instance (Singleton).
	 */
	public function set(string $id, $concrete, bool $shared = false): void
	{
		$this->services[$id] = [
			'concrete' => $concrete,
			'shared' => $shared,
		];
	}

	/**
	 * Get a service.
	 *
	 * @param string $id Service ID.
	 * @return object
	 * @throws Exception If service not found.
	 */
	public function get(string $id)
	{
		if (isset($this->instances[$id])) {
			return $this->instances[$id];
		}

		if (!isset($this->services[$id])) {
			// Auto-wiring attempt (simple)
			if (class_exists($id)) {
				return $this->resolve($id);
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception message is for developers, not end users
			throw new Exception("Service not found: {$id}");
		}

		$concrete = $this->services[$id]['concrete'];
		$object = null;

		if (is_callable($concrete)) {
			$object = $concrete($this);
		} elseif (is_object($concrete)) {
			$object = $concrete;
		} elseif (is_string($concrete) && class_exists($concrete)) {
			$object = $this->resolve($concrete);
		} else {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception message is for developers, not end users
			throw new Exception("Invalid service definition for: {$id}");
		}

		if ($this->services[$id]['shared']) {
			$this->instances[$id] = $object;
		}

		return $object;
	}

	/**
	 * Resolve dependencies automatically.
	 *
	 * @param string $class Class name.
	 * @return object
	 * @throws Exception If resolution fails.
	 */
	private function resolve(string $class)
	{
		$reflector = new ReflectionClass($class);

		if (!$reflector->isInstantiable()) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception message is for developers, not end users
			throw new Exception("Class {$class} is not instantiable");
		}

		$constructor = $reflector->getConstructor();

		if (null === $constructor) {
			return new $class();
		}

		$parameters = $constructor->getParameters();
		$dependencies = [];

		foreach ($parameters as $parameter) {
			$dependency_type = $parameter->getType();

			if (null === $dependency_type || $dependency_type->isBuiltin()) {
				if ($parameter->isDefaultValueAvailable()) {
					$dependencies[] = $parameter->getDefaultValue();
				} else {
					// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception message is for developers, not end users
					throw new Exception("Cannot resolve parameter {$parameter->getName()} in {$class}");
				}
			} else {
				$dependencies[] = $this->get($dependency_type->getName());
			}
		}

		return $reflector->newInstanceArgs($dependencies);
	}
}
