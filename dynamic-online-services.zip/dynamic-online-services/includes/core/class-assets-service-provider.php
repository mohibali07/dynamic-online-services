<?php
/**
 * Assets Service Provider
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Admin\AdminAssets;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class AssetsServiceProvider
 */
class AssetsServiceProvider implements ServiceProviderInterface
{
	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		// No binding needed for now, but could bind Asset classes if they needed dependencies
	}

	/**
	 * Boot services.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		// Frontend assets
		try {
			$frontend = new FrontendAssets();
			$frontend->init();
		} catch (\Exception $e) {
			// Log error
		}

		// Admin assets
		try {
			if (class_exists(AdminAssets::class)) {
				$admin = new AdminAssets();
				$admin->init();
			}
		} catch (\Exception $e) {
			// Log error
		}
	}
}
