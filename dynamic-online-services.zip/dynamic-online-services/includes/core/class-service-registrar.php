<?php
/**
 * Service Registrar Class
 *
 * Handles registration of custom post types and taxonomies.
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

if (!\defined('ABSPATH')) {
    exit;
}

use TechmireSolutions\DynamicOnlineServices\PostTypes\ServicePostType;
use TechmireSolutions\DynamicOnlineServices\Taxonomies\ServiceCategoryTaxonomy;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;

class ServiceRegistrar
{
	/**
	 * Settings Service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService $settings_service Settings service.
	 */
	public function __construct(SettingsService $settings_service)
	{
		$this->settings_service = $settings_service;
	}

    /**
     * Register post types and taxonomies.
     */
    public function register(): void
    {
        // Retrieve settings
        $service_slug  = $this->settings_service->get_option('service_post_type_slug', 'service');
        $taxonomy_slug = $this->settings_service->get_option('service_taxonomy_slug', 'service-category');

        // Register CPT
        $cpt = new ServicePostType($service_slug);
        $cpt->register();

        // Register taxonomy
        $tax = new ServiceCategoryTaxonomy($taxonomy_slug, [$service_slug]);
        $tax->register();
    }
}
?>
