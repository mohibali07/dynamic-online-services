<?php
/**
 * Template Loader Service
 *
 * Handles locating and rendering PHP templates with support for theme overrides.
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class TemplateLoader
 */
class TemplateLoader
{
	/**
	 * Base directory for plugin templates.
	 *
	 * @var string
	 */
	private $base_dir;

	/**
	 * Constructor.
	 *
	 * @param string $base_dir Base directory for templates.
	 */
	public function __construct(string $base_dir = '')
	{
		$this->base_dir = !empty($base_dir) ? $base_dir : DYNOS_PLUGIN_DIR . 'templates/';
	}

	/**
	 * Render a template.
	 *
	 * @param string $template_name Template name (without .php).
	 * @param array  $args          Arguments to extract into template scope.
	 * @return string Rendered HTML.
	 */
	public function render(string $template_name, array $args = []): string
	{
		$template_path = $this->locate_template($template_name);

		if (empty($template_path) || !file_exists($template_path)) {
			if (defined('WP_DEBUG') && WP_DEBUG) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log(sprintf('DYNOS TemplateLoader: Template not found: %s', $template_name));
			}
			return '';
		}

		// Extract args into scope
		if (!empty($args)) {
			extract($args); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		}

		ob_start();
		include $template_path;
		return ob_get_clean();
	}

	/**
	 * Locate a template.
	 *
	 * Checks theme first, then plugin.
	 *
	 * @param string $template_name Template name.
	 * @return string Full path to template file.
	 */
	private function locate_template(string $template_name): string
	{
		$template_name = str_replace('.php', '', $template_name) . '.php';

		// 1. Check for theme override
		$theme_path = locate_template('dynos/' . $template_name);
		if (!empty($theme_path)) {
			return $theme_path;
		}

		// 2. Fallback to plugin template
		return $this->base_dir . $template_name;
	}
}
