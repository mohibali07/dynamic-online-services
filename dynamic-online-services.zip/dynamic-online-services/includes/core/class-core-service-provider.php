<?php
/**
 * Core Service Provider
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\QueryServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Services\CardsQueryService;
use TechmireSolutions\DynamicOnlineServices\Renderers\CardsRenderer;

use TechmireSolutions\DynamicOnlineServices\Shortcodes\ShortcodeManager;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\Cards;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\Category;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\Faqs;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\CategoryHero;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\ServiceHero;
use TechmireSolutions\DynamicOnlineServices\Services\HeroDataService;
use TechmireSolutions\DynamicOnlineServices\Renderers\HeroRenderer;
use TechmireSolutions\DynamicOnlineServices\Services\CategoryQueryService;
use TechmireSolutions\DynamicOnlineServices\Renderers\CategoryRenderer;
use TechmireSolutions\DynamicOnlineServices\Services\FaqsQueryService;
use TechmireSolutions\DynamicOnlineServices\Renderers\FaqsRenderer;
use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\FAQs\MetaBox;
use TechmireSolutions\DynamicOnlineServices\FAQs\Saver;
use TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator;
use TechmireSolutions\DynamicOnlineServices\Services\PostDataService;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class CoreServiceProvider
 */
class CoreServiceProvider implements ServiceProviderInterface
{
	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		$container = Container::get_instance();

		// Register Template Loader
		$container->set(
			TemplateLoader::class,
			function () {
				return new TemplateLoader();
			},
			true
		);

		// NOTE: AdminNoticeService, SettingsService, PostDataService, CptSettingsValidator,
		// HeroDataService, and StyleService are now registered in DataServiceProvider.
		// Shortcodes (CategoryHero, ServiceHero) are now registered in ShortcodeServiceProvider.

		// Admin Notice Handler (uses AdminNoticeService from DataServiceProvider)
		$container->set(
			AdminNoticeHandler::class,
			function ($container) {
				return new AdminNoticeHandler(
					$container->get(AdminNoticeService::class)
				);
			},
			true // Shared
		);

		// Block Registrar
		$container->set(
			BlockRegistrar::class,
			function ($container) {
				return new BlockRegistrar(
					$container->get(AdminNoticeService::class)
				);
			},
			true // Shared
		);

		// Service Registrar (uses SettingsService from DataServiceProvider)
		$container->set(
			ServiceRegistrar::class,
			function ($container) {
				return new ServiceRegistrar(
					$container->get(SettingsService::class)
				);
			},
			true // Shared
		);

		// Cards Query Service
		$container->set(
			QueryServiceInterface::class,
			function ($container) {
				return new CardsQueryService(
					$container->get(CptSettingsValidator::class)
				);
			},
			true // Shared
		);

		// Cards Renderer (uses SettingsService and PostDataService from DataServiceProvider)
		$container->set(
			CardsRenderer::class,
			function ($container) {
				return new CardsRenderer(
					$container->get(SettingsService::class),
					$container->get(PostDataService::class),
					$container->get(TemplateLoader::class)
				);
			},
			true
		);

		// Cards Shortcode
		$container->set(
			Cards::class,
			function ($container) {
				return new Cards(
					$container->get(CardsRenderer::class),
					$container->get(QueryServiceInterface::class)
				);
			},
			true
		);

		// Category Query Service
		$container->set(
			CategoryQueryService::class,
			function ($container) {
				return new CategoryQueryService(
					$container->get(AdminNoticeService::class),
					$container->get(CptSettingsValidator::class),
					$container->get(PostDataService::class)
				);
			},
			true
		);

		// Category Renderer
		$container->set(
			CategoryRenderer::class,
			function ($container) {
				return new CategoryRenderer(
					$container->get(SettingsService::class),
					$container->get(PostDataService::class),
					$container->get(TemplateLoader::class)
				);
			},
			true
		);

		// Category Shortcode
		$container->set(
			Category::class,
			function ($container) {
				return new Category(
					$container->get(CategoryQueryService::class),
					$container->get(CategoryRenderer::class)
				);
			}
		);

		// FAQs Query Service
		$container->set(
			FaqsQueryService::class,
			function () {
				return new FaqsQueryService();
			},
			true
		);

		// FAQs Renderer
		$container->set(
			FaqsRenderer::class,
			function ($container) {
				return new FaqsRenderer(
					$container->get(TemplateLoader::class)
				);
			},
			true
		);

		// FAQs Shortcode
		$container->set(
			Faqs::class,
			function ($container) {
				return new Faqs(
					$container->get(FaqsQueryService::class),
					$container->get(FaqsRenderer::class)
				);
			}
		);

		// CCPT Settings Validator
		$container->set(
			CptSettingsValidator::class,
			function ($container) {
				return new CptSettingsValidator(
					$container->get(SettingsService::class),
					$container->get(AdminNoticeService::class)
				);
			},
			true
		);

		// FAQs MetaBox
		$container->set(
			MetaBox::class,
			function ($container) {
				return new MetaBox(
					$container->get(CptSettingsValidator::class)
				);
			},
			true
		);

		// FAQs Saver
		$container->set(
			Saver::class,
			function ($container) {
				return new Saver(
					$container->get(AdminNoticeService::class),
					$container->get(CptSettingsValidator::class)
				);
			},
			true
		);
	}

	/**
	 * Boot services.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		$container = Container::get_instance();

		// Boot Admin Notice Handler
		try {
			$admin_handler = $container->get(AdminNoticeHandler::class);
			add_action('admin_notices', [$admin_handler, 'display_activation_errors']);
		} catch (\Exception $e) {
			// Handle exception
		}

		// Boot Settings Service
		try {
			$container->get(SettingsService::class)->register_hooks();
		} catch (\Exception $e) {
			// Handle exception
		}

		// Boot Block Registrar
		try {
			$block_registrar = $container->get(BlockRegistrar::class);
			add_action('init', [$block_registrar, 'register']);
		} catch (\Exception $e) {
			// Handle exception
		}

		// Boot Service Registrar (Post Types & Taxonomies)
		// Usually hooked to 'init'
		try {
			$service_registrar = $container->get(ServiceRegistrar::class);
			add_action('init', [$service_registrar, 'register']);
		} catch (\Exception $e) {
			// Handle exception
		}



		// Boot FAQs
		try {
			// Register MetaBox
			$container->get(MetaBox::class)->register();
			// Register Saver
			$container->get(Saver::class)->register();
		} catch (\Exception $e) {
			$this->log_error($e, 'FAQ Initialization Failed');
		}

		// Boot Shortcodes
		try {
			$shortcode_manager = $container->get(ShortcodeManager::class);

			// Register Shortcodes
			$shortcode_manager->register($container->get(Cards::class));
			$shortcode_manager->register($container->get(Category::class));
			$shortcode_manager->register($container->get(Faqs::class));
			$shortcode_manager->register($container->get(CategoryHero::class));
			$shortcode_manager->register($container->get(ServiceHero::class));

			// Boot Manager
			$shortcode_manager->boot();

		} catch (\Exception $e) {
			$this->log_error($e, 'Shortcode Initialization Failed');
		}

		// I18n
		try {
			$container->set(I18n::class, function () {
				return new I18n();
			}, true);
			$container->get(I18n::class)->load();
		} catch (\Exception $e) {
			$this->log_error($e, 'I18n Loading Failed');
		}

		// Integrations are now handled by IntegrationServiceProvider
	}

	/**
	 * Log errors helper.
	 *
	 * @param \Exception $e
	 * @param string $context
	 */
	private function log_error(\Exception $e, string $context): void {
		if (\defined('WP_DEBUG') && WP_DEBUG) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			\error_log(
				\sprintf(
					'DYNOS %s: %s in %s:%d',
					$context,
					$e->getMessage(),
					$e->getFile(),
					$e->getLine()
				)
			);
		}

		// Set transient for admin notice (simplified key for all init errors)
		set_transient(
			'dynos_component_init_error',
			\sprintf(
				/* translators: %s: error message */
				__('Dynamic Online Services initialization error: %s', 'dynamic-online-services'),
				$e->getMessage()
			),
			30
		);
	}
}
