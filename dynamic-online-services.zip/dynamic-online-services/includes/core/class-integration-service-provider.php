<?php
/**
 * Integration Service Provider
 *
 * Handles registration and bootstrapping of third-party integration services.
 *
 * @package Dynamic_Online_Services
 * @subpackage Core
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Core;

use TechmireSolutions\DynamicOnlineServices\Core\Container;
use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Integration\LiteSpeedCache;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Integration Service Provider.
 */
class IntegrationServiceProvider implements ServiceProviderInterface {

	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void {
		$container = Container::get_instance();

		// LiteSpeed Cache Integration
		$container->set(
			LiteSpeedCache::class,
			function () {
				return new LiteSpeedCache();
			},
			true
		);
	}

	/**
	 * Bootstrap services.
	 *
	 * @return void
	 */
	public function boot(): void {
		$container = Container::get_instance();

		// Only initialize if LiteSpeed Cache plugin is active
		if ( defined( 'LSCWP_V' ) ) {
			$litespeed_cache = $container->get( LiteSpeedCache::class );
			$litespeed_cache->register();
		}
	}
}
