<?php
/**
 * FAQ Accordion Styles
 *
 * Handles enqueuing of FAQ accordion styles with dynamic options.
 *
 * @package Dynamic_Online_Services
 * @subpackage Styles
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Styles;

use TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Core\Container;

use WP_Post;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * FAQ Styles class.
 */
class FaqStyles extends AbstractStyles
{
	/**
	 * Enqueue FAQ accordion styles with dynamic options.
	 *
	 * @since 1.2.0
	 * @param bool $force Whether to force load styles.
	 */
	public static function enqueue(bool $force = false): void
	{
		$validator = new \TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator();
		$settings = $validator->get_settings();
		$service_slug = isset($settings['service_slug']) ? $settings['service_slug'] : 'service';

		if (!self::should_load($force, '', 'service_faqs_accordion')) {
			// Check specific service slug singular logic which might not be covered by generic should_load
			// AbstractStyles::should_load checks is_tax and generic singular + shortcode.
			// Here we have is_singular($service_slug) check + meta check.
			// We need to keep this custom logic.
			$load_styles = false;
			if (is_singular($service_slug)) {
				$post = get_queried_object();
				if (!$post || !($post instanceof WP_Post)) {
					$post = get_post();
				}

				if ($post && isset($post->ID)) {
					$faqs = get_post_meta($post->ID, 'service_faqs', true);
					if (is_array($faqs) && !empty($faqs)) {
						$load_styles = true;
					}
				}
			}

			if (!$load_styles) {
				return;
			}
		}

		// Allow filtering whether to load styles (Generic filter not present in original but we can skip or keep logic)
		// Original didn't have a generic filter before options?
		// Original lines 44-77 handled loading logic.
		// My AbstractStyles::should_load covers basic strict shortcode chcek.
		// But here we had custom meta check.
		// So I combined abstract check (which returns true if force or simple shortcode match)
		// BUT wait, AbstractStyles::should_load returns true if has_shortcode.
		// If I use !self::should_load(...), it returns false if NO shortcode.
		// But valid case is: NO shortcode, but IS singular service with meta.
		// So simple !should_load return is WRONG here because it would exit early.
		// I should use should_load as partial check?

		// Let's rewrite logic:
		$should_load = self::should_load($force, '', 'service_faqs_accordion');

		if (!$should_load) {
			// Check custom logic
			if (is_singular($service_slug)) {
				$post = get_queried_object();
				if (!$post || !($post instanceof WP_Post)) {
					$post = get_post();
				}

				if ($post && isset($post->ID)) {
					$faqs = get_post_meta($post->ID, 'service_faqs', true);
					if (is_array($faqs) && !empty($faqs)) {
						$should_load = true;
					}
				}
			}
		}

		if (!$should_load) {
			return;
		}

		// Get SettingsService from container
		$container = Container::get_instance();
		$settings = $container->get(SettingsService::class);

		$faq_border_color = $settings->get_option('faq_item_border_color', '#ddd');
		$faq_border_radius = $settings->get_option('faq_item_border_radius', '8px');
		$faq_margin_bottom = $settings->get_option('faq_item_margin_bottom', '15px');
		$faq_box_shadow = $settings->get_option('faq_item_box_shadow', '0 2px 4px rgba(0, 0, 0, 0.05)');
		$faq_question_bg = $settings->get_option('faq_question_bg_color', '#f7f7f7');
		$faq_question_bg_hover = $settings->get_option('faq_question_bg_hover', '#eee');
		$faq_question_text = $settings->get_option('faq_question_text_color', '#333');
		$faq_answer_text = $settings->get_option('faq_answer_text_color', '#333');
		$faq_question_padding = $settings->get_option('faq_question_padding', '15px 20px');
		$faq_question_font_size = $settings->get_option('faq_question_font_size', '1.15rem');
		$faq_icon_font_size = $settings->get_option('faq_icon_font_size', '1.5rem');
		$faq_answer_padding = $settings->get_option('faq_answer_padding', '20px');
		$faq_answer_max_height = $settings->get_option('faq_answer_max_height', '500px');
		$faq_transition_speed = $settings->get_option('faq_transition_speed', '0.4s');

		// Sanitize and escape all CSS values to prevent injection
		$faq_border_color = sanitize_hex_color($faq_border_color);
		$faq_border_radius = Sanitization::escape_css_value($faq_border_radius, 'border-radius');
		$faq_margin_bottom = Sanitization::escape_css_value($faq_margin_bottom, 'margin');
		$faq_box_shadow = Sanitization::escape_css_value($faq_box_shadow, 'box-shadow');
		$faq_question_bg = sanitize_hex_color($faq_question_bg);
		$faq_question_bg_hover = sanitize_hex_color($faq_question_bg_hover);
		$faq_question_text = sanitize_hex_color($faq_question_text);
		$faq_answer_text = sanitize_hex_color($faq_answer_text);
		$faq_question_padding = Sanitization::escape_css_value($faq_question_padding, 'padding');
		$faq_question_font_size = Sanitization::escape_css_value($faq_question_font_size, 'font-size');
		$faq_icon_font_size = Sanitization::escape_css_value($faq_icon_font_size, 'font-size');
		$faq_answer_padding = Sanitization::escape_css_value($faq_answer_padding, 'padding');
		$faq_answer_max_height = Sanitization::escape_css_value($faq_answer_max_height, 'max-height');
		$faq_transition_speed = Sanitization::escape_css_value($faq_transition_speed, '');


		// Enqueue base FAQ styles
		wp_enqueue_style(
			'dynos-faqs-accordion',
			DYNOS_PLUGIN_URL . 'assets/public/css/faqs-accordion.css',
			[],
			DYNOS_VERSION
		);

		wp_enqueue_script(
			'dynos-faqs-accordion',
			DYNOS_PLUGIN_URL . 'assets/public/js/faqs-accordion.js',
			['jquery'],
			DYNOS_VERSION,
			true
		);

		// Build dynamic CSS using safe CSS building functions
		$dynamic_css = '.faq-item {';
		$dynamic_css .= Sanitization::build_css_rule('border', '1px solid ' . $faq_border_color);
		$dynamic_css .= Sanitization::build_css_rule('border-radius', $faq_border_radius);
		$dynamic_css .= Sanitization::build_css_rule('margin-bottom', $faq_margin_bottom);
		$dynamic_css .= Sanitization::build_css_rule('box-shadow', $faq_box_shadow);
		$dynamic_css .= '}';

		$dynamic_css .= '.faq-question {';
		$dynamic_css .= Sanitization::build_css_rule('background-color', $faq_question_bg);
		$dynamic_css .= Sanitization::build_css_rule('color', $faq_question_text);
		$dynamic_css .= Sanitization::build_css_rule('padding', $faq_question_padding);
		$dynamic_css .= Sanitization::build_css_rule('font-size', $faq_question_font_size);
		$dynamic_css .= '}';

		$dynamic_css .= '.faq-question:hover {';
		$dynamic_css .= Sanitization::build_css_rule('background-color', $faq_question_bg_hover);
		$dynamic_css .= '}';

		$dynamic_css .= '.faq-icon {';
		$dynamic_css .= Sanitization::build_css_rule('font-size', $faq_icon_font_size);
		$dynamic_css .= Sanitization::build_css_rule('transition', 'transform ' . $faq_transition_speed . ' ease');
		$dynamic_css .= '}';

		$dynamic_css .= '.faq-answer {';
		$dynamic_css .= Sanitization::build_css_rule('color', $faq_answer_text);
		$dynamic_css .= Sanitization::build_css_rule('transition', 'max-height ' . $faq_transition_speed . ' ease-out, padding ' . $faq_transition_speed . ' ease-out');
		$dynamic_css .= '}';

		$dynamic_css .= '.faq-answer.show {';
		$dynamic_css .= Sanitization::build_css_rule('max-height', $faq_answer_max_height);
		$dynamic_css .= Sanitization::build_css_rule('padding', $faq_answer_padding);
		$dynamic_css .= '}';

		// Allow filtering the CSS
		$dynamic_css = apply_filters('dynos_faq_dynamic_css', $dynamic_css);

		wp_add_inline_style('dynos-faqs-accordion', $dynamic_css);
	}
}
