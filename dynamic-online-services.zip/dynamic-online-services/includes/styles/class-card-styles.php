<?php
/**
 * Service Card Styles
 *
 * Handles enqueuing of service card styles with dynamic options.
 *
 * @package Dynamic_Online_Services
 * @subpackage Styles
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Styles;

use TechmireSolutions\DynamicOnlineServices\Helpers\Fonts;
use TechmireSolutions\DynamicOnlineServices\Helpers\FontManager;
use TechmireSolutions\DynamicOnlineServices\Helpers\Cache;
use TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Core\Container;

use WP_Post;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Card Styles class.
 */
class CardStyles extends AbstractStyles
{
	/**
	 * Enqueue service card styles with dynamic options.
	 *
	 * @since 1.2.0
	 * @param bool $force Whether to force load styles.
	 */
	public static function enqueue(bool $force = false): void
	{
		$validator = new \TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator();
		$settings = $validator->get_settings();
		$taxonomy_slug = isset($settings['taxonomy_slug']) ? $settings['taxonomy_slug'] : 'services_category';

		if (!self::should_load($force, $taxonomy_slug, 'service_category_content')) {
			return;
		}

		// Allow filtering whether to load styles (redundant check if already checked in should_load but keeps filter for specific context if needed, though should_load covers basic logic)
		// We keep the specific filter here as checking valid post logic is partly done.
		// Actually, let's trust should_load for the basics and apply the filter.
		$load_styles = true;
		$post = \get_post();
		$load_styles = apply_filters('dynos_should_load_card_styles', $load_styles, $post);

		if (!$load_styles) {
			return;
		}

		// Get SettingsService from container
		$container = Container::get_instance();
		$settings = $container->get(SettingsService::class);

		$card_bg = $settings->get_option('card_bg_color', '#6A4B3F');
		$card_title = $settings->get_option('card_title_color', '#FFFFFF');
		$card_desc = $settings->get_option('card_description_color', '#e0e0e0');
		$card_btn_bg = $settings->get_option('card_button_bg_color', '#0081A7');
		$card_btn_text = $settings->get_option('card_button_text_color', '#FFFFFF');
		$card_font = $settings->get_option('card_font_family', 'Helvetica');

		// Enqueue base card styles
		wp_enqueue_style(
			'dynos-service-cards',
			DYNOS_PLUGIN_URL . 'assets/public/css/service-cards.css',
			[],
			DYNOS_VERSION
		);

		// PERFORMANCE FIX: Queue font instead of immediate enqueue
		// FontManager combines all font requests into a single API call
		FontManager::queue_font($card_font);

		// Allow filtering CSS values
		$card_bg = apply_filters('dynos_card_bg_color', $card_bg);
		$card_title = apply_filters('dynos_card_title_color', $card_title);
		$card_desc = apply_filters('dynos_card_description_color', $card_desc);
		$card_btn_bg = apply_filters('dynos_card_button_bg_color', $card_btn_bg);
		$card_btn_text = apply_filters('dynos_card_button_text_color', $card_btn_text);
		$card_font = apply_filters('dynos_card_font_family', $card_font);

		// Sanitize CSS values
		$card_bg = sanitize_hex_color($card_bg);
		$card_title = sanitize_hex_color($card_title);
		$card_desc = sanitize_hex_color($card_desc);
		$card_btn_bg = sanitize_hex_color($card_btn_bg);
		$card_btn_text = sanitize_hex_color($card_btn_text);
		$card_font = esc_attr($card_font);

		// Get additional card settings
		$card_title_size = $settings->get_option('card_title_font_size', '1.25rem');
		$card_desc_size = $settings->get_option('card_description_font_size', '0.9rem');
		$card_btn_size = $settings->get_option('card_button_font_size', '0.9rem');
		$card_border_radius = $settings->get_option('card_border_radius', '18px');
		$card_height = $settings->get_option('card_height', '400px');
		$card_image_height = $settings->get_option('card_image_height', '232px');
		$card_content_height = $settings->get_option('card_content_height', '200px');
		$card_content_padding_top = $settings->get_option('card_content_padding_top', '24px');
		$card_content_padding_sides = $settings->get_option('card_content_padding_sides', '10px');
		$card_grid_min_width = $settings->get_option('card_grid_min_width', '280px');
		$card_grid_column_gap = $settings->get_option('card_grid_column_gap', '20px');
		$card_grid_row_gap = $settings->get_option('card_grid_row_gap', '40px');
		$card_hover_transform = $settings->get_option('card_hover_transform', 'translateY(-5px)');
		$card_hover_transition = $settings->get_option('card_hover_transition', '0.2s');
		$card_box_shadow = $settings->get_option('card_box_shadow', '0 4px 6px rgba(0, 0, 0, 0.1)');
		$card_btn_hover_bg = $settings->get_option('card_button_hover_bg_color', '#FFFFFF');
		$card_btn_hover_text = $settings->get_option('card_button_hover_text_color', '#0081A7');

		// Sanitize and escape all CSS values to prevent injection
		$card_title_size = Sanitization::escape_css_value($card_title_size, 'font-size');
		$card_desc_size = Sanitization::escape_css_value($card_desc_size, 'font-size');
		$card_btn_size = Sanitization::escape_css_value($card_btn_size, 'font-size');
		$card_border_radius = Sanitization::escape_css_value($card_border_radius, 'border-radius');
		$card_height = Sanitization::escape_css_value($card_height, 'height');
		$card_image_height = Sanitization::escape_css_value($card_image_height, 'height');
		$card_content_height = Sanitization::escape_css_value($card_content_height, 'height');
		$card_content_padding_top = Sanitization::escape_css_value($card_content_padding_top, 'padding');
		$card_content_padding_sides = Sanitization::escape_css_value($card_content_padding_sides, 'padding');
		$card_grid_min_width = Sanitization::escape_css_value($card_grid_min_width, 'min-width');
		$card_grid_column_gap = Sanitization::escape_css_value($card_grid_column_gap, 'padding');
		$card_grid_row_gap = Sanitization::escape_css_value($card_grid_row_gap, 'padding');
		$card_hover_transform = Sanitization::escape_css_value($card_hover_transform, 'transform');
		$card_hover_transition = Sanitization::escape_css_value($card_hover_transition, '');
		$card_box_shadow = Sanitization::escape_css_value($card_box_shadow, 'box-shadow');
		$card_btn_hover_bg = sanitize_hex_color($card_btn_hover_bg);
		$card_btn_hover_text = sanitize_hex_color($card_btn_hover_text);

		// Escape font family for safe use in CSS
		$card_font_escaped = esc_attr($card_font);

		// PERFORMANCE FIX: Cache generated CSS to avoid regeneration on every page load
		// Create array of all settings for cache key generation
		$card_settings = [
			'bg' => $card_bg,
			'title' => $card_title,
			'desc' => $card_desc,
			'btn_bg' => $card_btn_bg,
			'btn_text' => $card_btn_text,
			'font' => $card_font_escaped,
			'title_size' => $card_title_size,
			'desc_size' => $card_desc_size,
			'btn_size' => $card_btn_size,
			'border_radius' => $card_border_radius,
			'height' => $card_height,
			'image_height' => $card_image_height,
			'content_height' => $card_content_height,
			'padding_top' => $card_content_padding_top,
			'padding_sides' => $card_content_padding_sides,
			'grid_min_width' => $card_grid_min_width,
			'column_gap' => $card_grid_column_gap,
			'row_gap' => $card_grid_row_gap,
			'hover_transform' => $card_hover_transform,
			'hover_transition' => $card_hover_transition,
			'box_shadow' => $card_box_shadow,
			'btn_hover_bg' => $card_btn_hover_bg,
			'btn_hover_text' => $card_btn_hover_text,
		];

		// Create cache key from settings hash
		$settings_hash = md5(wp_json_encode($card_settings));
		$cache_key = 'dynos_card_css_' . $settings_hash;

		// Try to get cached CSS
		$dynamic_css = get_transient($cache_key);

		if (false === $dynamic_css) {
			// Generate CSS if not cached
			$dynamic_css = self::generate_card_css(
				$card_settings,
				$card_grid_min_width,
				$card_grid_column_gap,
				$card_grid_row_gap,
				$card_border_radius,
				$card_height,
				$card_box_shadow,
				$card_hover_transition,
				$card_hover_transform,
				$card_image_height,
				$card_bg,
				$card_title,
				$card_font_escaped,
				$card_content_padding_top,
				$card_content_padding_sides,
				$card_content_height,
				$card_title_size,
				$card_desc,
				$card_desc_size,
				$card_btn_bg,
				$card_btn_text,
				$card_btn_size,
				$card_btn_hover_bg,
				$card_btn_hover_text
			);

			// Cache for 24 hours (settings rarely change)
			set_transient($cache_key, $dynamic_css, \TechmireSolutions\DynamicOnlineServices\Helpers\Cache::CACHE_DURATION_LONG);
		}

		// Allow filtering the CSS before adding
		$dynamic_css = apply_filters('dynos_card_dynamic_css', $dynamic_css);

		wp_add_inline_style('dynos-service-cards', $dynamic_css);
	}

	/**
	 * Generate card CSS.
	 *
	 * @since 1.2.0
	 * @param array  $settings All card settings.
	 * @param string $grid_min_width Grid minimum width.
	 * @param string $grid_column_gap Grid column gap.
	 * @param string $grid_row_gap Grid row gap.
	 * @param string $border_radius Border radius.
	 * @param string $height Card height.
	 * @param string $box_shadow Box shadow.
	 * @param string $hover_transition Hover transition.
	 * @param string $hover_transform Hover transform.
	 * @param string $image_height Image height.
	 * @param string $bg_color Background color.
	 * @param string $title_color Title color.
	 * @param string $font_family Font family.
	 * @param string $padding_top Padding top.
	 * @param string $padding_sides Padding sides.
	 * @param string $content_height Content height.
	 * @param string $title_size Title font size.
	 * @param string $desc_color Description color.
	 * @param string $desc_size Description font size.
	 * @param string $btn_bg Button background.
	 * @param string $btn_text Button text color.
	 * @param string $btn_size Button font size.
	 * @param string $btn_hover_bg Button hover background.
	 * @param string $btn_hover_text Button hover text color.
	 * @return string Generated CSS.
	 */
	private static function generate_card_css(
		array $settings,
		string $grid_min_width,
		string $grid_column_gap,
		string $grid_row_gap,
		string $border_radius,
		string $height,
		string $box_shadow,
		string $hover_transition,
		string $hover_transform,
		string $image_height,
		string $bg_color,
		string $title_color,
		string $font_family,
		string $padding_top,
		string $padding_sides,
		string $content_height,
		string $title_size,
		string $desc_color,
		string $desc_size,
		string $btn_bg,
		string $btn_text,
		string $btn_size,
		string $btn_hover_bg,
		string $btn_hover_text
	): string {
		// Extract settings from array for use in CSS generation
		$card_bg = $settings['bg'];
		$card_title = $settings['title'];
		$card_desc = $settings['desc'];
		$card_btn_bg = $settings['btn_bg'];
		$card_btn_text = $settings['btn_text'];
		$card_font_escaped = $settings['font'];
		$card_title_size = $settings['title_size'];
		$card_desc_size = $settings['desc_size'];
		$card_btn_size = $settings['btn_size'];
		$card_border_radius = $settings['border_radius'];
		$card_height = $settings['height'];
		$card_image_height = $settings['image_height'];
		$card_content_height = $settings['content_height'];
		$card_content_padding_top = $settings['padding_top'];
		$card_content_padding_sides = $settings['padding_sides'];
		$card_grid_min_width = $settings['grid_min_width'];
		$card_grid_column_gap = $settings['column_gap'];
		$card_grid_row_gap = $settings['row_gap'];
		$card_hover_transform = $settings['hover_transform'];
		$card_hover_transition = $settings['hover_transition'];
		$card_box_shadow = $settings['box_shadow'];
		$card_btn_hover_bg = $settings['btn_hover_bg'];
		$card_btn_hover_text = $settings['btn_hover_text'];

		// Build dynamic CSS using safe CSS building functions
		$dynamic_css = '.service-card-grid {';
		$dynamic_css .= Sanitization::build_css_rule('grid-template-columns', 'repeat(auto-fit, minmax(' . $card_grid_min_width . ', 1fr))');
		$dynamic_css .= Sanitization::build_css_rule('column-gap', $card_grid_column_gap);
		$dynamic_css .= Sanitization::build_css_rule('row-gap', $card_grid_row_gap);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card {';
		$dynamic_css .= Sanitization::build_css_rule('border-radius', $card_border_radius);
		$dynamic_css .= Sanitization::build_css_rule('height', $card_height);
		$dynamic_css .= Sanitization::build_css_rule('box-shadow', $card_box_shadow);
		$dynamic_css .= Sanitization::build_css_rule('transition', 'transform ' . $card_hover_transition);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card:hover {';
		$dynamic_css .= Sanitization::build_css_rule('transform', $card_hover_transform);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-image-link {';
		$dynamic_css .= Sanitization::build_css_rule('height', $card_image_height);
		$dynamic_css .= Sanitization::build_css_rule('border-radius', $card_border_radius);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-image {';
		$dynamic_css .= Sanitization::build_css_rule('height', $card_image_height);
		$dynamic_css .= Sanitization::build_css_rule('border-radius', $card_border_radius);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-content {';
		$dynamic_css .= Sanitization::build_css_rule('background-color', $card_bg);
		$dynamic_css .= Sanitization::build_css_rule('color', $card_title);
		$dynamic_css .= Sanitization::build_css_rule('font-family', $card_font_escaped . ', sans-serif');
		$dynamic_css .= Sanitization::build_css_rule('padding', $card_content_padding_top . ' ' . $card_content_padding_sides . ' 0');
		$dynamic_css .= Sanitization::build_css_rule('height', $card_content_height);
		$dynamic_css .= Sanitization::build_css_rule('border-radius', '0 0 ' . $card_border_radius . ' ' . $card_border_radius);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-title, .service-card-title a {';
		$dynamic_css .= Sanitization::build_css_rule('color', $card_title);
		$dynamic_css .= Sanitization::build_css_rule('font-size', $card_title_size);
		$dynamic_css .= '}';

		// Allow filtering hover color (defaults to white for contrast)
		$card_title_hover_color = apply_filters('dynos_card_title_hover_color', '#ffffff');
		$card_title_hover_color = sanitize_hex_color($card_title_hover_color);
		if (empty($card_title_hover_color)) {
			$card_title_hover_color = '#ffffff';
		}

		$dynamic_css .= '.service-card-title a:hover {';
		$dynamic_css .= Sanitization::build_css_rule('color', $card_title_hover_color);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-description {';
		$dynamic_css .= Sanitization::build_css_rule('color', $card_desc);
		$dynamic_css .= Sanitization::build_css_rule('font-size', $card_desc_size);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-link {';
		$dynamic_css .= Sanitization::build_css_rule('background-color', $card_btn_bg);
		// Use inline style approach for !important (safer than string concatenation)
		$color_rule = Sanitization::build_css_rule('color', $card_btn_text);
		if (!empty($color_rule)) {
			$dynamic_css .= rtrim($color_rule, ';') . ' !important;';
		}
		$dynamic_css .= Sanitization::build_css_rule('font-size', $card_btn_size);
		$dynamic_css .= '}';

		$dynamic_css .= '.service-card-link:hover {';
		$dynamic_css .= Sanitization::build_css_rule('background-color', $card_btn_hover_bg);
		// Use inline style approach for !important (safer than string concatenation)
		$hover_color_rule = Sanitization::build_css_rule('color', $card_btn_hover_text);
		if (!empty($hover_color_rule)) {
			$dynamic_css .= rtrim($hover_color_rule, ';') . ' !important;';
		}
		$dynamic_css .= '}';

		return $dynamic_css;
	}
}
