<?php
/**
 * Abstract Styles Class
 *
 * Base class for handling style enqueueing and dynamic CSS.
 *
 * @package Dynamic_Online_Services
 * @subpackage Styles
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Styles;

use WP_Post;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Abstract Class AbstractStyles
 */
abstract class AbstractStyles
{
	/**
	 * Initialize hooks.
	 */
	public static function init(): void
	{
		add_action('wp_enqueue_scripts', [static::class, 'enqueue']);
	}

	/**
	 * Enqueue styles.
	 *
	 * @param bool $force Whether to force load styles.
	 */
	abstract public static function enqueue(bool $force = false): void;

	/**
	 * Check if styles should be loaded.
	 *
	 * @param bool   $force         Force load.
	 * @param string $taxonomy_slug Taxonomy slug to check.
	 * @param string $shortcode     Shortcode to check.
	 * @return bool True if styles should be loaded.
	 */
	protected static function should_load(bool $force, string $taxonomy_slug = '', string $shortcode = ''): bool
	{
		if ($force) {
			return true;
		}

		if (!empty($taxonomy_slug) && is_tax($taxonomy_slug)) {
			return true;
		}

		$current_post = get_post();
		if ($current_post instanceof WP_Post) {
			// Check if is singular and has shortcode
			if (!empty($shortcode) && has_shortcode($current_post->post_content, $shortcode)) {
				return true;
			}
		}

		return false;
	}
}
