<?php
/**
 * Style Service
 *
 * Injectable service for managing and enqueueing styles.
 * Replaces static HeroStyles class.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class StyleService
 */
class StyleService
{
	/**
	 * Track if hero styles have been enqueued.
	 *
	 * @var bool
	 */
	private static $hero_styles_enqueued = false;

	/**
	 * Enqueue hero styles.
	 *
	 * @param string $font_family   Font family for hero.
	 * @param string $overlay_color Overlay color for hero.
	 * @return void
	 */
	public function enqueue_hero_styles(string $font_family, string $overlay_color): void
	{
		// Prevent duplicate enqueuing
		if (self::$hero_styles_enqueued) {
			return;
		}

		// Check if HeroStyles class exists (backward compatibility)
		if (class_exists('TechmireSolutions\\DynamicOnlineServices\\Styles\\HeroStyles')) {
			\TechmireSolutions\DynamicOnlineServices\Styles\HeroStyles::enqueue($font_family, $overlay_color);
			self::$hero_styles_enqueued = true;
		}
	}

	/**
	 * Enqueue card styles.
	 *
	 * @return void
	 */
	public function enqueue_card_styles(): void
	{
		// Placeholder for future card-specific styles
		// Currently cards use default WordPress styles
	}

	/**
	 * Reset enqueued flag (useful for testing).
	 *
	 * @return void
	 */
	public function reset(): void
	{
		self::$hero_styles_enqueued = false;
	}
}
