<?php
/**
 * Settings Service
 *
 * Encapsulates global settings retrieval.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

defined( 'ABSPATH' ) || exit;

use TechmireSolutions\DynamicOnlineServices\Settings\Defaults;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Helpers\Cache;

/**
 * Class SettingsService
 */
class SettingsService implements SettingsServiceInterface
{

	/**
	 * Settings array.
	 *
	 * @var array|null
	 */
	private $options;

	/**
	 * Settings cache key.
	 */
	private const CACHE_KEY = 'dynos_options';

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Initialize options from cache or db
		$this->options = $this->retrieve_options();
	}

	/**
	 * Register hooks for cache invalidation.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'update_option', [ $this, 'maybe_invalidate_cache' ], 10, 3 );
		add_action( 'add_option', [ $this, 'maybe_invalidate_cache_on_add' ], 10, 2 );
		add_action( 'delete_option', [ $this, 'maybe_invalidate_cache_on_delete' ], 10 );
	}

	/**
	 * Get all options.
	 *
	 * @return array
	 */
	public function get_options(): array {
		if ( null === $this->options ) {
			$this->options = $this->retrieve_options();
		}
		return $this->options;
	}

	/**
	 * Get a specific option value.
	 *
	 * @param string $key Option key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get_option( string $key, $default = '' ): mixed {
		$options = $this->get_options();
		$value   = isset( $options[ $key ] ) ? $options[ $key ] : $default;
		return apply_filters( 'dynos_get_option', $value, $key, $default, $options );
	}

	/**
	 * Refresh options.
	 */
	public function refresh(): void {
		$this->options = $this->retrieve_options( true );
	}

	/**
	 * Retrieve options with caching logic.
	 *
	 * @param bool $force_refresh Whether to force refresh.
	 * @return array
	 */
	private function retrieve_options( bool $force_refresh = false ): array {
		// Layer 1: Check transient version
		$cache_version = get_transient( 'dynos_options_cache_version' );
		if ( false === $cache_version ) {
			$force_refresh = true;
		}

		// Layer 2: Hash check
		$last_update = get_transient( 'dynos_options_last_update' );
		if ( false !== $last_update ) {
			$current_options = get_option( 'dynos_options', false );
			if ( false !== $current_options ) {
				// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
				$options_hash = md5( maybe_serialize( $current_options ) ?? '' );
				$cached_hash  = get_transient( 'dynos_options_hash' );
				if ( $cached_hash !== $options_hash ) {
					$force_refresh = true;
					set_transient( 'dynos_options_hash', $options_hash, Cache::CACHE_DURATION_MEDIUM );
				}
			}
		}

		// Layer 3: Return if cached in memory and not forced
		if ( ! empty( $this->options ) && ! $force_refresh ) {
			return $this->options;
		}

		// Retrieve from DB
		$defaults = Defaults::get_options();
		$options  = get_option( 'dynos_options', $defaults );
		$options  = wp_parse_args( $options, $defaults );

		$options = apply_filters( 'dynos_get_options', $options );
		if ( ! is_array( $options ) ) {
			$options = (array) $options;
		}

		// Set transients (settings are semi-static, use medium duration)
		set_transient( 'dynos_options_cache_version', time(), Cache::CACHE_DURATION_MEDIUM );
		set_transient( 'dynos_options_last_update', time(), Cache::CACHE_DURATION_MEDIUM );
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
		set_transient( 'dynos_options_hash', md5( maybe_serialize( $options ) ?? '' ), Cache::CACHE_DURATION_MEDIUM );

		return $options;
	}

	/**
	 * Invalidate cache.
	 */
	private function invalidate_cache(): void {
		delete_transient( 'dynos_options_cache_version' );
		delete_transient( 'dynos_options_last_update' );
		delete_transient( 'dynos_options_hash' );
		$this->options = null;

		// PERFORMANCE FIX: Clear CSS caches when settings change
		// This ensures new card settings generate fresh CSS
		$this->invalidate_css_caches();

		do_action( 'dynos_options_cache_invalidated' );
	}

	/**
	 * Invalidate all CSS caches.
	 *
	 * Clears dynamically generated CSS transients when settings change.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	private function invalidate_css_caches(): void {
		global $wpdb;

		// Clear all card CSS caches (pattern: dynos_card_css_*)
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			WHERE option_name LIKE '_transient_dynos_card_css_%'
			OR option_name LIKE '_transient_timeout_dynos_card_css_%'"
		);
	}

	/**
	 * Hook callback for update_option.
	 *
	 * @param mixed  $old_value Old value.
	 * @param mixed  $value     New value.
	 * @param string $option    Option name.
	 */
	public function maybe_invalidate_cache( $old_value, $value, $option ): void {
		if ( 'dynos_options' === $option ) {
			$this->invalidate_cache();
			set_transient( 'dynos_options_last_update', time(), Cache::CACHE_DURATION_MEDIUM );
			if ( is_array( $value ) ) {
				// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
				set_transient( 'dynos_options_hash', md5( maybe_serialize( $value ) ?? '' ), Cache::CACHE_DURATION_MEDIUM );
			}
		}
	}

	/**
	 * Hook callback for add_option.
	 *
	 * @param string $option Option name.
	 * @param mixed  $value  Value.
	 */
	public function maybe_invalidate_cache_on_add( $option, $value ): void {
		if ( 'dynos_options' === $option ) {
			$this->invalidate_cache();
			set_transient( 'dynos_options_last_update', time(), Cache:: CACHE_DURATION_MEDIUM );
			if ( is_array( $value ) ) {
				// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
				set_transient( 'dynos_options_hash', md5( maybe_serialize( $value ) ?? '' ), Cache::CACHE_DURATION_MEDIUM );
			}
		}
	}

	/**
	 * Hook callback for delete_option.
	 *
	 * @param string $option Option name.
	 */
	public function maybe_invalidate_cache_on_delete( $option ): void {
		if ( 'dynos_options' === $option ) {
			$this->invalidate_cache();
			delete_transient( 'dynos_options_last_update' );
			delete_transient( 'dynos_options_hash' );
		}
	}
}
