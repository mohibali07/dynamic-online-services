<?php
/**
 * FAQs Query Service
 *
 * Handles fetching FAQs for the shortcode.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * FaqsQueryService class.
 */
class FaqsQueryService {

	/**
	 * Get FAQs for a service post.
	 *
	 * @since 1.2.0
	 * @param int $post_id Post ID.
	 * @return array Array of FAQs or empty array.
	 */
	public function get_faqs( int $post_id ): array {
		$faqs = get_post_meta( $post_id, 'service_faqs', true );

		if ( ! is_array( $faqs ) || empty( $faqs ) ) {
			return [];
		}

		// Sanitize FAQ data to ensure security
		$sanitized_faqs = [];
		foreach ( $faqs as $faq ) {
			if ( ! is_array( $faq ) ) {
				continue;
			}

			$question = isset( $faq['question'] ) ? sanitize_text_field( $faq['question'] ) : '';
			$answer   = isset( $faq['answer'] ) ? wp_kses_post( $faq['answer'] ) : '';

			// Only include FAQs with valid questions
			if ( ! empty( $question ) ) {
				$sanitized_faqs[] = [
					'question' => $question,
					'answer'   => $answer,
				];
			}
		}

		// Allow filtering FAQs before return
		return apply_filters( 'dynos_faqs_before_display', $sanitized_faqs, $post_id );
	}

	/**
	 * Validate post ID.
	 *
	 * @param int $post_id Post ID.
	 * @return int|false Valid post ID or false.
	 */
	public function validate_post_id( $post_id ) {
        // Simple validation wrapper, similar to dynos_validate_post_id if it exists
        // Assuming basic validation logic here as the original function was calling dynos_validate_post_id
        // We will just do basic int validation here or rely on caller?
        // The original logic called dynos_validate_post_id.
        // We can check if that function exists or just implement basic check.

        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return false;
        }
        return $post_id;
    }
}
