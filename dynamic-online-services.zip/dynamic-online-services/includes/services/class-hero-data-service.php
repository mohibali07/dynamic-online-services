<?php
/**
 * Hero Data Service
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\PostDataServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\CptSettingsServiceInterface;
use WP_Term;
use WP_Post;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class HeroDataService
 */
class HeroDataService implements ServiceInterface
{
	/**
	 * Settings Service.
	 *
	 * @var SettingsServiceInterface
	 */
	private $settings_service;

	/**
	 * Post Data Service.
	 *
	 * @var PostDataServiceInterface
	 */
	private $post_data_service;

	/**
	 * CPT Settings Service.
	 *
	 * @var CptSettingsServiceInterface
	 */
	private $cpt_settings;

	/**
	 * Constructor.
	 *
	 * @param SettingsServiceInterface    $settings_service Settings Service.
	 * @param PostDataServiceInterface    $post_data_service Post Data Service.
	 * @param CptSettingsServiceInterface $cpt_settings CPT Settings Service.
	 */
	public function __construct(
		SettingsServiceInterface $settings_service,
		PostDataServiceInterface $post_data_service,
		CptSettingsServiceInterface $cpt_settings
	) {
		$this->settings_service = $settings_service;
		$this->post_data_service = $post_data_service;
		$this->cpt_settings = $cpt_settings;
	}

	/**
	 * Get taxonomy slug from CPT settings.
	 *
	 * Helper method for shortcodes.
	 *
	 * @since 1.2.0
	 * @return string Taxonomy slug.
	 */
	public function get_taxonomy_slug(): string
	{
		return $this->cpt_settings->get_taxonomy_slug();
	}

	/**
	 * Get service post type slug from CPT settings.
	 *
	 * Helper method for shortcodes.
	 *
	 * @since 1.2.0
	 * @return string Service slug.
	 */
	public function get_service_slug(): string
	{
		return $this->cpt_settings->get_service_slug();
	}

	/**
	 * Get hero data for category archive pages.
	 *
	 * @param WP_Term $term Term object.
	 * @return array Hero data array.
	 */
	public function get_category_hero_data(WP_Term $term): array
	{
		// Use injected CPT settings service
		$taxonomy_slug = $this->cpt_settings->get_taxonomy_slug();

		// Get thumbnail
		$thumbnail_id = get_term_meta($term->term_id, 'service_cat_thumbnail', true);
		$image_url = '';
		if ($thumbnail_id) {
			// Simplified validation vs global function
			$attachment_url = wp_get_attachment_image_url((int)$thumbnail_id, 'full');
			if ($attachment_url) {
				$image_url = esc_url($attachment_url);
			}
		}

		// Get settings via Service
		$hero_title_color = $this->settings_service->get_option('hero_title_color', '#FFFFFF');
		$hero_overlay_color = $this->settings_service->get_option('hero_overlay_color', '#000000');
		$hero_font_family = $this->settings_service->get_option('hero_font_family', 'Helvetica');
		$hero_height = $this->settings_service->get_option('hero_height', '50vh');

		// Allow filtering values
		$hero_title_color = apply_filters('dynos_category_hero_title_color', $hero_title_color, $term);
		$hero_font_family = apply_filters('dynos_category_hero_font_family', $hero_font_family, $term);
		$image_url = apply_filters('dynos_category_hero_image_url', $image_url, $term);
		$hero_height = apply_filters('dynos_category_hero_height', $hero_height, $term);
		$title = apply_filters('dynos_category_hero_title', $term->name, $term);

		return [
			'image_url' => $image_url,
			'height' => $hero_height,
			'title_color' => $hero_title_color,
			'font_family' => $hero_font_family,
			'title' => $title,
			'description' => '',
			'data_attribute' => 'data-term-id',
			'data_value' => $term->term_id,
			'overlay_color' => $hero_overlay_color,
		];
	}

	/**
	 * Get hero data for single service pages.
	 *
	 * @param WP_Post $post Post object.
	 * @return array Hero data array.
	 */
	public function get_service_hero_data(WP_Post $post): array
	{
		$post_id = $post->ID;

		// Get banner image and description using PostDataService
		$image_array = $this->post_data_service->get_service_banner_image($post_id);
		$description = $this->post_data_service->get_service_description($post_id);
		$post_title = get_the_title($post_id);

		$image_url = '';
		if (is_array($image_array) && isset($image_array['url'])) {
			$image_url = esc_url($image_array['url']);
		}

		// Get settings via Service
		$hero_title_color = $this->settings_service->get_option('hero_title_color', '#FFFFFF');
		$hero_overlay_color = $this->settings_service->get_option('hero_overlay_color', '#000000');
		$hero_font_family = $this->settings_service->get_option('hero_font_family', 'sans-serif');
		$hero_height = $this->settings_service->get_option('hero_height', '50vh');

		// Allow filtering values
		$hero_title_color = apply_filters('dynos_service_hero_title_color', $hero_title_color, $post);
		$hero_font_family = apply_filters('dynos_service_hero_font_family', $hero_font_family, $post);
		$image_url = apply_filters('dynos_service_hero_image_url', $image_url, $post);
		$hero_height = apply_filters('dynos_service_hero_height', $hero_height, $post);
		$post_title = apply_filters('dynos_service_hero_title', $post_title, $post);
		$description = apply_filters('dynos_service_hero_description', $description, $post);

		return [
			'image_url' => $image_url,
			'height' => $hero_height,
			'title_color' => $hero_title_color,
			'font_family' => $hero_font_family,
			'title' => $post_title,
			'description' => $description,
			'data_attribute' => 'data-post-id',
			'data_value' => $post->ID,
			'overlay_color' => $hero_overlay_color,
		];
	}
}
