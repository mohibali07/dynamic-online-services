<?php
/**
 * Admin Notice Service
 *
 * Handles displaying admin notices and logging errors.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

use TechmireSolutions\DynamicOnlineServices\Interfaces\AdminNoticeServiceInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AdminNoticeService
 */
class AdminNoticeService implements AdminNoticeServiceInterface {

	/**
	 * Display a user-friendly admin notice.
	 *
	 * @param string $message     Message to display.
	 * @param string $type        Notice type: 'error', 'warning', 'success', 'info'. Default 'info'.
	 * @param bool   $dismissible Whether the notice is dismissible. Default true.
	 */
	public function show( string $message, string $type = 'info', bool $dismissible = true ): void {
		if ( empty( $message ) ) {
			return;
		}

		$allowed_types = [ 'error', 'warning', 'success', 'info' ];
		if ( ! in_array( $type, $allowed_types, true ) ) {
			$type = 'info';
		}

		$class = 'notice notice-' . esc_attr( $type );
		if ( $dismissible ) {
			$class .= ' is-dismissible';
		}

		printf(
			'<div class="%1$s"><p>%2$s</p></div>',
			esc_attr( $class ),
			wp_kses_post( $message )
		);
	}

	/**
	 * Display a success notice.
	 *
	 * @param string $message Success message.
	 */
	public function success( string $message ): void {
		$this->show( $message, 'success', true );
	}

	/**
	 * Display an error notice.
	 *
	 * @param string $message Error message.
	 */
	public function error( string $message ): void {
		$this->show( $message, 'error', true );
	}

	/**
	 * Display a warning notice.
	 *
	 * @param string $message Warning message.
	 */
	public function warning( string $message ): void {
		$this->show( $message, 'warning', true );
	}

	/**
	 * Display an info notice.
	 *
	 * @param string $message Info message.
	 */
	public function info( string $message ): void {
		$this->show( $message, 'info', true );
	}

	/**
	 * Add a validation warning admin notice.
	 *
	 * @param string $message     The warning message to display.
	 * @param string $log_message Optional log message for WP_DEBUG. Default empty.
	 */
	public function add_validation_warning( string $message, string $log_message = '' ): void {
		// Log warning in debug mode
		if ( ! empty( $log_message ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$this->log_error( $log_message, 'warning' );
		}

		// Add admin notice for user feedback
		if ( is_admin() && current_user_can( 'manage_options' ) ) {
			add_action(
				'admin_notices',
				function () use ( $message ) {
					printf(
						'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
						wp_kses_post( $message )
					);
				}
			);
		}
	}

	/**
	 * Centralized error logging function.
	 *
	 * @param string $message Error message to log.
	 * @param string $level   Log level: 'error', 'warning', 'info', 'debug'. Default 'error'.
	 * @param array  $context Additional context data. Default empty array.
	 */
	public function log_error( string $message, string $level = 'error', array $context = [] ): void {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		$allowed_levels = [ 'error', 'warning', 'info', 'debug' ];
		if ( ! in_array( $level, $allowed_levels, true ) ) {
			$level = 'error';
		}

		$formatted_message = 'DYNOS [' . strtoupper( $level ) . ']: ' . $message;

		if ( ! empty( $context ) ) {
			$formatted_message .= ' | Context: ' . wp_json_encode( $context );
		}

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( $formatted_message );

		do_action( 'dynos_log_error', $message, $level, $context );
	}
}
