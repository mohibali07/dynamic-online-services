<?php
/**
 * Configuration Service
 *
 * Centralized service for managing plugin configuration values.
 * Handles filterable constants with transient caching.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 * @since 1.2.0
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

use TechmireSolutions\DynamicOnlineServices\Helpers\Cache;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class ConfigurationService
 */
class ConfigurationService
{
	/**
	 * Cache group for transients.
	 */
	private const CACHE_GROUP = 'dynos_config';

	/**
	 * Cache duration (24 hours - static config
	 */
	private const CACHE_DURATION = Cache::CACHE_DURATION_LONG;

	/**
	 * Get tablet breakpoint value.
	 *
	 * @return string Breakpoint value (e.g., '768px').
	 */
	public function get_breakpoint_tablet(): string
	{
		return $this->get_cached_config(
			'breakpoint_tablet',
			'dynos_breakpoint_tablet',
			'768px'
		);
	}

	/**
	 * Get mobile breakpoint value.
	 *
	 * @return string Breakpoint value (e.g., '480px').
	 */
	public function get_breakpoint_mobile(): string
	{
		return $this->get_cached_config(
			'breakpoint_mobile',
			'dynos_breakpoint_mobile',
			'480px'
		);
	}

	/**
	 * Get maximum grid columns.
	 *
	 * @return int Maximum columns (default: 6).
	 */
	public function get_max_grid_columns(): int
	{
		return (int) $this->get_cached_config(
			'max_grid_columns',
			'dynos_max_grid_columns',
			6,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get minimum grid columns.
	 *
	 * @return int Minimum columns (default: 1).
	 */
	public function get_min_grid_columns(): int
	{
		return (int) $this->get_cached_config(
			'min_grid_columns',
			'dynos_min_grid_columns',
			1,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get maximum taxonomy hierarchy depth.
	 *
	 * @return int Maximum depth (default: 10).
	 */
	public function get_max_taxonomy_depth(): int
	{
		return (int) $this->get_cached_config(
			'max_taxonomy_depth',
			'dynos_max_taxonomy_depth',
			10,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get default excerpt length.
	 *
	 * @return int Excerpt length in words (default: 20).
	 */
	public function get_default_excerpt_length(): int
	{
		return (int) $this->get_cached_config(
			'default_excerpt_length',
			'dynos_default_excerpt_length',
			20,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get maximum posts per page.
	 *
	 * @return int Maximum posts (default: 100).
	 */
	public function get_max_posts_per_page(): int
	{
		return (int) $this->get_cached_config(
			'max_posts_per_page',
			'dynos_max_posts_per_page',
			100,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get default grid minimum width.
	 *
	 * @return string Grid minimum width (e.g., '280px').
	 */
	public function get_default_grid_min_width(): string
	{
		return $this->get_cached_config(
			'default_grid_min_width',
			'dynos_default_grid_min_width',
			'280px',
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get maximum FAQs per post.
	 *
	 * @return int Maximum FAQs (default: 100).
	 */
	public function get_max_faqs_per_post(): int
	{
		return (int) $this->get_cached_config(
			'max_faqs_per_post',
			'dynos_max_faqs_per_post',
			100,
			false // Don't cache this one - always run filter
		);
	}

	/**
	 * Get a cached configuration value.
	 *
	 * @param string $key     Cache key.
	 * @param string $filter  Filter hook name.
	 * @param mixed  $default Default value.
	 * @param bool   $cache   Whether to cache the result.
	 * @return mixed Filtered configuration value.
	 */
	private function get_cached_config(string $key, string $filter, $default, bool $cache = true)
	{
		if (!$cache) {
			// Always run filter for transparency
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- Dynamic filter name is intentional for flexibility
			return apply_filters($filter, $default);
		}

		$cache_key = "dynos_{$key}_cached";
		$cached = get_transient($cache_key);

		if (false !== $cached) {
			return $cached;
		}

		// Run filter and cache result
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- Dynamic filter name is intentional for flexibility
		$value = apply_filters($filter, $default);
		set_transient($cache_key, $value, self::CACHE_DURATION);

		return $value;
	}

	/**
	 * Clear all cached configuration values.
	 *
	 * Useful for development or when filter values change.
	 *
	 * @return void
	 */
	public function clear_cache(): void
	{
		$keys = [
			'breakpoint_tablet',
			'breakpoint_mobile',
		];

		foreach ($keys as $key) {
			delete_transient("dynos_{$key}_cached");
		}
	}

	/**
	 * Define all plugin constants.
	 *
	 * Used by ConfigurationServiceProvider to ensure constants are defined.
	 * This is a no-op since constants should be defined in main plugin file.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function define_constants(): void
	{
		// Constants are defined in main plugin file
		// This method exists for explicit calls from ConfigurationServiceProvider
		// No-op - constants should already be defined by WordPress
	}
}
