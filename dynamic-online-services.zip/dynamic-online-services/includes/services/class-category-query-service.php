<?php
/**
 * Category Query Service
 *
 * Handles fetching categories and services for the category shortcode.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

require_once dirname(dirname(__DIR__)) . '/includes/helpers/class-cache-helper.php';

use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;
use TechmireSolutions\DynamicOnlineServices\Services\PostDataService;
use TechmireSolutions\DynamicOnlineServices\Helpers\CacheHelper;
use TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator;
use WP_Query;
use WP_Term;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Category Query Service class.
 */
class CategoryQueryService {

	/**
	 * Admin Notice Service.
	 *
	 * @var AdminNoticeService
	 */
	private $admin_notice_service;

	/**
	 * CPT Settings Validator.
	 *
	 * @var CptSettingsValidator
	 */
	private $cpt_settings_validator;

	/**
	 * Post Data Service.
	 *
	 * @var PostDataService
	 */
	private $post_data_service;

	/**
     * Cache Helper.
     *
     * @var \TechmireSolutions\DynamicOnlineServices\Interfaces\CacheHelperInterface
     */
    private $cache_helper;

    /**
     * Constructor.
     *
     * @param AdminNoticeService $admin_notice_service Admin Notice Service.
     * @param CptSettingsValidator $cpt_settings_validator CPT Settings Validator.
     * @param PostDataService $post_data_service Post Data Service.
     * @param \TechmireSolutions\DynamicOnlineServices\Interfaces\CacheHelperInterface|null $cache_helper Cache Helper.
     */
    public function __construct(
        ?AdminNoticeService $admin_notice_service = null,
        ?CptSettingsValidator $cpt_settings_validator = null,
        ?PostDataService $post_data_service = null,
        ?\TechmireSolutions\DynamicOnlineServices\Interfaces\CacheHelperInterface $cache_helper = null
    ) {
        $this->admin_notice_service = $admin_notice_service ?: new AdminNoticeService();
        $this->cpt_settings_validator = $cpt_settings_validator ?: new CptSettingsValidator();
        $this->post_data_service = $post_data_service ?: new PostDataService();
        $this->cache_helper = $cache_helper ?: new CacheHelper();
    }

	/**
	 * Get child categories for the current term.
	 *
	 * @since 1.2.0
	 * @param WP_Term $term Current term object.
	 * @param bool    $hide_empty Whether to hide empty categories.
	 * @return array Array of category items to display.
	 */
	public function get_child_categories( WP_Term $term, bool $hide_empty ): array {
		$items = [];

		$settings = $this->cpt_settings_validator->sanitize_cpt_settings();
		$taxonomy_slug = isset( $settings['taxonomy_slug'] ) ? $settings['taxonomy_slug'] : 'services_category';

		$child_categories = get_terms(
			[
				'taxonomy'   => $taxonomy_slug,
				'parent'     => absint( $term->term_id ),
				'hide_empty' => $hide_empty,
			]
		);

		if ( ! is_wp_error( $child_categories ) && ! empty( $child_categories ) ) {
			// FIX: Batch-fetch all term meta to avoid N+1 query problem
			$term_ids = wp_list_pluck( $child_categories, 'term_id' );
			$thumbnails_map = [];

			if ( ! empty( $term_ids ) ) {
			// PERFORMANCE FIX: Cache term meta query (term data rarely changes)
			$cache_key = 'dynos_term_thumbnails_' . md5( implode( ',', $term_ids ) );
			$thumbnails_map = get_transient( $cache_key );

			if ( false === $thumbnails_map ) {
				global $wpdb;

				// SECURITY FIX: Use proper prepared statement with placeholders
				// Build placeholders for IN clause (%d for each term ID)
				$placeholders = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );

				// Prepare query parameters: term IDs array + meta_key string
				$query_params = array_merge( $term_ids, [ 'service_cat_thumbnail' ] );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT term_id, meta_value FROM {$wpdb->termmeta}
						WHERE term_id IN ({$placeholders})
						AND meta_key = %s",
						...$query_params
					)
				);

				$thumbnails_map = [];
				foreach ( $results as $row ) {
					$thumbnails_map[ $row->term_id ] = $row->meta_value;
				}

				// Cache for 24 hours (term meta rarely changes)
				set_transient( $cache_key, $thumbnails_map, \TechmireSolutions\DynamicOnlineServices\Helpers\Cache::CACHE_DURATION_LONG );
			}
		}

			foreach ( $child_categories as $category ) {
				/** @var WP_Term $category */

				$thumbnail_id = isset( $thumbnails_map[ $category->term_id ] ) ? $thumbnails_map[ $category->term_id ] : '';
				$term_link    = get_term_link( $category );

				if ( is_wp_error( $term_link ) ) {
					$this->admin_notice_service->log_error(
						sprintf(
							'Failed to get term link for term ID %d (%s): %s',
							$category->term_id,
							$category->name,
							$term_link->get_error_message()
						),
						'warning',
						[
							'term_id'    => $category->term_id,
							'term_name'  => $category->name,
							'error_code' => $term_link->get_error_code(),
						]
					);
					do_action( 'dynos_category_content_term_link_error', $category, $term_link );
					continue;
				}

				$items[] = [
					'type'        => 'category',
					'title'       => $category->name,
					'description' => wp_trim_words( $category->description, defined('DYNOS_DEFAULT_EXCERPT_LENGTH') ? DYNOS_DEFAULT_EXCERPT_LENGTH : 20 ),
					'url'         => $term_link,
					'image_id'    => $thumbnail_id ? intval( $thumbnail_id ) : 0,
				];
			}
		}

		return $items;
	}

	/**
	 * Get services for the current term.
	 *
	 * @since 1.2.0
	 * @param WP_Term $term Current term object.
	 * @param array   $atts Shortcode attributes.
	 * @return array Array containing services and pagination info.
	 */
	public function get_services( WP_Term $term, array $atts ): array {
		$posts_per_page = isset($atts['posts_per_page']) ? (int) $atts['posts_per_page'] : -1;
		$orderby        = isset($atts['orderby']) ? $atts['orderby'] : 'menu_order';
		$order          = isset($atts['order']) ? $atts['order'] : 'ASC';
		$pagination     = isset($atts['pagination']) && filter_var($atts['pagination'], FILTER_VALIDATE_BOOLEAN);
		$paged          = isset($atts['paged']) ? (int) $atts['paged'] : 1;

		$settings = $this->cpt_settings_validator->sanitize_cpt_settings();
		$service_slug  = isset( $settings['service_slug'] ) ? $settings['service_slug'] : 'service';
		$taxonomy_slug = isset( $settings['taxonomy_slug'] ) ? $settings['taxonomy_slug'] : 'services_category';

		$query_args = [
			'post_type'      => $service_slug,
			'posts_per_page' => $posts_per_page > 0 ? $posts_per_page : -1,
			'orderby'        => $orderby,
			'order'          => $order,
			'tax_query'      => [
				[
					'taxonomy'         => $taxonomy_slug,
					'field'            => 'term_id',
					'terms'            => absint( $term->term_id ),
					'include_children' => false,
				],
			],
			'post_status'    => 'publish',
			'no_found_rows'  => ! $pagination,
		];

		if ( $pagination && $posts_per_page > 0 ) {
			$query_args['paged']         = $paged;
			$query_args['no_found_rows'] = false;
		}

		$query_args = apply_filters( 'dynos_category_content_query_args', $query_args, $term );

		if ( $pagination && $posts_per_page > 0 ) {
			$services_query = new WP_Query( $query_args );
			$services       = $services_query->posts;
			$total_pages    = $services_query->max_num_pages;
			$current_page   = $paged;
		} else {
			// PERFORMANCE FIX: Use caching for non-paginated results
			// Paginated results are not cached to avoid cache pollution
			$cache_disabled = apply_filters( 'dynos_category_query_disable_cache', false );

            // Cache check
            $cache_key = 'dynos_cat_services_' . $term->term_id . '_' . $paged;
            $cached = $this->cache_helper->get_posts($cache_key);
            if ($cached) {
                return $cached;
            }

			if ( ! $cache_disabled ) {
				$services_query = \TechmireSolutions\DynamicOnlineServices\Helpers\Cache::get_posts( $query_args );
				$services       = $services_query->posts;
			} else {
				$services = get_posts( $query_args );
			}

			$total_pages  = 0;
			$current_page = 1;
		}

		$services = apply_filters( 'dynos_category_content_services', $services, $term );

	// PERFORMANCE FIX: Preload all post meta to prevent N+1 queries
	// This eliminates 150+ separate database queries when rendering 50 services
	if ( ! empty( $services ) ) {
		$post_ids = wp_list_pluck( $services, 'ID' );

		// Preload all post meta (including ACF fields)
		update_meta_cache( 'post', $post_ids );

		// Preload ACF meta specifically if ACF is active
		// This ensures ACF's get_field() uses cached data
		if ( function_exists( 'acf_get_store' ) ) {
			update_postmeta_cache( $post_ids );
		}
	}

	$items = [];
	foreach ( $services as $service_post ) {
			$image_array = $this->post_data_service->get_service_banner_image( $service_post->ID );
			$description = $this->post_data_service->get_service_description( $service_post->ID );

			$image_url = '';
			$image_alt = esc_attr( $service_post->post_title );

			if ( is_array( $image_array ) && isset( $image_array['url'] ) ) {
				$image_url = esc_url( $image_array['url'] );
				if ( isset( $image_array['alt'] ) && ! empty( $image_array['alt'] ) ) {
					$image_alt = esc_attr( $image_array['alt'] );
				}
			}

			$permalink = get_permalink( $service_post );

			if ( ! $permalink ) {
				continue;
			}

			$items[] = [
				'type'        => 'post',
				'title'       => $service_post->post_title,
				'description' => wp_trim_words( $description, DYNOS_DEFAULT_EXCERPT_LENGTH ),
				'url'         => $permalink,
				'image_url'   => $image_url,
				'image_alt'   => $image_alt,
			];
		}

		return [
			'items'        => $items,
			'total_pages'  => $total_pages,
			'current_page' => $current_page,
		];
	}
}
