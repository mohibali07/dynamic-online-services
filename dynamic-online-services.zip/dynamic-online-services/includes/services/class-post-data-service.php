<?php
/**
 * Post Data Service
 *
 * Handles retrieval of post-related data like images, descriptions, and placeholders.
 * Replaces functionality of Helpers\Images.
 *
 * @package Dynamic_Online_Services
 * @subpackage Services
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Services;

use TechmireSolutions\DynamicOnlineServices\Helpers\Acf;
use TechmireSolutions\DynamicOnlineServices\Interfaces\PostDataServiceInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PostDataService
 */
class PostDataService implements PostDataServiceInterface {

	/**
	 * Get default placeholder image URL.
	 *
	 * @param string $size Image size. Default 'full'.
	 * @return string Placeholder image URL.
	 */
	public function get_placeholder_url( string $size = 'full' ): string {
		// Allow filtering the placeholder URL
		$placeholder_url = apply_filters( 'dynos_placeholder_image_url', '', $size );

		if ( ! empty( $placeholder_url ) ) {
			return esc_url( $placeholder_url );
		}

		// Try to use a local placeholder if it exists
		$local_placeholder = DYNOS_PLUGIN_URL . 'assets/public/images/placeholder.png';
		$local_path        = DYNOS_PLUGIN_DIR . 'assets/public/images/placeholder.png';

		// Check if file exists and is readable
		if ( file_exists( $local_path ) && is_readable( $local_path ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$image_info = @getimagesize( $local_path );
			if ( false !== $image_info ) {
				return esc_url( $local_placeholder );
			}
		}

		// Fallback to a simple data URI placeholder (SVG)
		$no_image_text = __( 'No Image', 'dynamic-online-services' );
		$no_image_text = wp_strip_all_tags( $no_image_text );
		$no_image_text = esc_html( $no_image_text );

		$svg_content = sprintf(
			'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="232" viewBox="0 0 400 232"><rect width="400" height="232" fill="#e0e0e0"/><text x="50%%" y="50%%" text-anchor="middle" dy=".3em" fill="#999" font-family="sans-serif" font-size="16">%s</text></svg>',
			$no_image_text
		);

		// Encode SVG content safely using base64
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		$encoded = base64_encode( $svg_content );

		return 'data:image/svg+xml;base64,' . $encoded;
	}

	/**
	 * Get service banner image with fallback to featured image.
	 *
	 * @param int $post_id Post ID.
	 * @return array Image array with 'url' and optionally 'alt' keys, or empty array if no image found.
	 */
	public function get_service_banner_image( int $post_id ): array {
		$post_id = absint( $post_id );
		if ( 0 === $post_id ) {
			return [];
		}

		// Get ACF banner image field
		// Note: Still using static Acf helper for now. Could be injected if Acf becomes a service.
		$image_array = Acf::get_field( 'banner_bg_image', $post_id, [] );

		// Fallback: use featured image if ACF image is not available
		if ( empty( $image_array ) || ! is_array( $image_array ) ) {
			$thumbnail_id = get_post_thumbnail_id( $post_id );
			if ( $thumbnail_id ) {
				$image_url = wp_get_attachment_image_url( $thumbnail_id, 'full' );
				if ( $image_url ) {
					$image_array = [ 'url' => $image_url ];
					// Try to get alt text from featured image
					$image_alt = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
					if ( ! empty( $image_alt ) ) {
						$image_array['alt'] = $image_alt;
					}
				}
			}
		}

		// Ensure we return a valid array structure
		if ( is_array( $image_array ) && isset( $image_array['url'] ) ) {
			return $image_array;
		}

		return [];
	}

	/**
	 * Get service description with fallback to excerpt.
	 *
	 * @param int $post_id Post ID.
	 * @return string Description text or empty string.
	 */
	public function get_service_description( int $post_id ): string {
		$post_id = absint( $post_id );
		if ( 0 === $post_id ) {
			return '';
		}

		// Get ACF description field
		$description = Acf::get_field( 'banner_description', $post_id, '' );

		// Fallback: use post excerpt if ACF description is not available
		if ( empty( $description ) ) {
			$description = get_the_excerpt( $post_id );
		}

		return $description;
	}
}
