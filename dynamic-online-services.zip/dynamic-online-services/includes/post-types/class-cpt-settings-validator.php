<?php
/**
 * Post Type Settings Validator
 *
 * Handles validation and sanitization of post type and taxonomy settings.
 *
 * @package Dynamic_Online_Services
 * @subpackage PostTypes
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\PostTypes;

use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Interfaces\AdminNoticeServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\CptSettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization as HelperSanitization;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * CptSettingsValidator class.
 */
class CptSettingsValidator implements CptSettingsServiceInterface
{
	/**
	 * Settings Service.
	 *
	 * @var SettingsServiceInterface
	 */
	private $settings_service;

	/**
	 * Admin Notice Service.
	 *
	 * @var AdminNoticeServiceInterface
	 */
	private $admin_notice_service;

	/**
	 * Cached settings to avoid multiple calls.
	 *
	 * @var array|null
	 */
	private $cached_settings = null;

	/**
	 * Constructor.
	 *
	 * @param SettingsServiceInterface    $settings_service    Settings service.
	 * @param AdminNoticeServiceInterface $admin_notice_service Admin notice service.
	 */
	public function __construct(
		?SettingsServiceInterface $settings_service = null,
		?AdminNoticeServiceInterface $admin_notice_service = null
	) {
		$this->settings_service = $settings_service ?: new SettingsService();
		$this->admin_notice_service = $admin_notice_service ?: new AdminNoticeService();
	}

	/**
	 * Get sanitized and validated post type and taxonomy settings.
	 *
	 * Implements CptSettingsServiceInterface::get_settings()
	 *
	 * @since 1.1.0
	 * @since 1.2.0 Renamed from sanitize_cpt_settings, added caching
	 * @return array Array with sanitized 'service_slug', 'taxonomy_slug', 'menu_position', and 'menu_icon'.
	 */
	public function get_settings(): array
	{
		// Return cached settings if available
		if (null !== $this->cached_settings) {
			return $this->cached_settings;
		}
		$service_slug = $this->settings_service->get_option('service_post_type_slug', 'services');
		$taxonomy_slug = $this->settings_service->get_option('service_taxonomy_slug', 'service-category');
		$menu_position = $this->settings_service->get_option('service_menu_position', '');
		$menu_icon = $this->settings_service->get_option('service_menu_icon', 'dashicons-admin-customizer');

		// Custom Labels
		$cpt_singular = $this->settings_service->get_option('service_cpt_singular_name', 'Service');
		$cpt_plural = $this->settings_service->get_option('service_cpt_plural_name', 'Services');
		$tax_singular = $this->settings_service->get_option('service_tax_singular_name', 'Service Category');
		$tax_plural = $this->settings_service->get_option('service_tax_plural_name', 'Service Categories');

		// Sanitize slugs using centralized validation function
		$service_slug = HelperSanitization::validate_slug($service_slug, 'services');
		$taxonomy_slug = HelperSanitization::validate_slug($taxonomy_slug, 'service-category');

		// Validate menu position
		$menu_position = $this->validate_menu_position($menu_position);

		// Validate menu icon
		$menu_icon = $this->validate_menu_icon($menu_icon);

			// Cache and return settings
		$this->cached_settings = [
			'service_slug' => $service_slug,
			'taxonomy_slug' => $taxonomy_slug,
			'menu_position' => $menu_position,
			'menu_icon' => $menu_icon,
			'cpt_singular' => $cpt_singular,
			'cpt_plural' => $cpt_plural,
			'tax_singular' => $tax_singular,
			'tax_plural' => $tax_plural,
		];

		return $this->cached_settings;
	}

	/**
	 * Alias for get_settings() for backward compatibility.
	 *
	 * @deprecated 1.2.0 Use get_settings() instead.
	 * @return array
	 */
	public function sanitize_cpt_settings(): array
	{
		return $this->get_settings();
	}

	/**
	 * Get service post type slug.
	 *
	 * Implements CptSettingsServiceInterface::get_service_slug()
	 *
	 * @since 1.2.0
	 * @return string Service slug.
	 */
	public function get_service_slug(): string
	{
		$settings = $this->get_settings();
		return $settings['service_slug'] ?? 'services';
	}

	/**
	 * Get taxonomy slug.
	 *
	 * Implements CptSettingsServiceInterface::get_taxonomy_slug()
	 *
	 * @since 1.2.0
	 * @return string Taxonomy slug.
	 */
	public function get_taxonomy_slug(): string
	{
		$settings = $this->get_settings();
		return $settings['taxonomy_slug'] ?? 'service-category';
	}

	/**
	 * Validate menu position value.
	 *
	 * @since 1.1.0
	 * @param mixed $menu_position Menu position value.
	 * @return int|null Validated menu position or null for default.
	 */
	public function validate_menu_position($menu_position): ?int
	{
		$menu_position = !empty($menu_position) ? absint($menu_position) : null;

		if (null !== $menu_position && ($menu_position < 0 || $menu_position > 100)) {
			// Use centralized validation warning function
			$warning_message = sprintf(
				/* translators: %s: Invalid menu position value */
				esc_html__('Dynamic Online Services: Invalid menu position value (%s). Menu position must be between 0 and 100, or left empty. Using default position.', 'dynamic-online-services'),
				esc_html((string)$menu_position)
			);
			$this->admin_notice_service->add_validation_warning($warning_message, 'Invalid menu position ' . $menu_position . '. Using default.');
			$menu_position = null;
		}

		return $menu_position;
	}

	/**
	 * Validate menu icon format.
	 *
	 * @since 1.1.0
	 * @param string $menu_icon Menu icon class name.
	 * @return string Validated menu icon class name.
	 */
	public function validate_menu_icon(string $menu_icon): string
	{
		$menu_icon = sanitize_text_field($menu_icon);
		if (empty($menu_icon)) {
			return 'dashicons-admin-customizer';
		}

		// Validate dashicon format (basic check)
		if (!preg_match('/^dashicons-[a-z0-9-]+$/i', $menu_icon)) {
			// Use centralized validation warning function
			$warning_message = sprintf(
				/* translators: %s: Invalid menu icon value */
				esc_html__('Dynamic Online Services: Invalid menu icon format (%s). Icon must be a valid Dashicon class name (e.g., dashicons-admin-customizer). Using default icon.', 'dynamic-online-services'),
				esc_html($menu_icon)
			);
			$this->admin_notice_service->add_validation_warning($warning_message, 'Invalid menu icon format: ' . $menu_icon . '. Using default.');
			return 'dashicons-admin-customizer';
		}

		return $menu_icon;
	}
}
