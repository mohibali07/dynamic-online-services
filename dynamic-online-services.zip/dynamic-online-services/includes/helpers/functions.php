<?php
/**
 * Global Helper Functions
 *
 * @package Dynamic_Online_Services
 * @subpackage Helpers
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'dynos_is_post_edit_screen' ) ) {
	/**
	 * Check if current screen is a post edit screen.
	 *
	 * @param string|null $post_type Optional. Check for specific post type.
	 * @return bool True if on post edit screen, false otherwise.
	 */
	function dynos_is_post_edit_screen( $post_type = null ): bool {
		if ( ! is_admin() ) {
			return false;
		}

		global $pagenow;

		// Check if we are on the edit page
		if ( 'post.php' !== $pagenow && 'post-new.php' !== $pagenow ) {
			return false;
		}

		// If no post type specified, just return true
		if ( null === $post_type ) {
			return true;
		}

		// Check post type
		$current_post_type = '';

		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( isset( $_GET['post_type'] ) ) {
			$current_post_type = sanitize_key( $_GET['post_type'] );
		} elseif ( isset( $_GET['post'] ) ) {
			$post_id = absint( $_GET['post'] );
			$current_post_type = get_post_type( $post_id );
		} elseif ( isset( $_POST['post_ID'] ) ) {
			$post_id = absint( $_POST['post_ID'] );
			$current_post_type = get_post_type( $post_id );
		}
		// phpcs:enable

		return $post_type === $current_post_type;
	}
}
