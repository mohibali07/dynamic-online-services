<?php
/**
 * Font Manager Class
 *
 * Queues and combines Google Font requests into a single API call.
 *
 * @package Dynamic_Online_Services
 * @subpackage Helpers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Helpers;

if (!\defined('ABSPATH')) {
	exit;
}

/**
 * Class FontManager
 *
 * PERFORMANCE OPTIMIZATION: Combines multiple Google Font requests
 * into a single API call to reduce HTTP overhead.
 *
 * @since 1.2.0
 */
class FontManager
{
	/**
	 * Queued fonts to load.
	 *
	 * @var array
	 */
	private static $queued_fonts = [];

	/**
	 * Whether footer action has been registered.
	 *
	 * @var bool
	 */
	private static $hook_registered = false;

	/**
	 * Queue a Google Font for loading.
	 *
	 * Fonts are combined and loaded in wp_footer to reduce HTTP requests.
	 *
	 * @since 1.2.0
	 * @param string $font_family Font family name.
	 * @return void
	 */
	public static function queue_font(string $font_family): void
	{
		if (empty($font_family) || !Fonts::is_google_font($font_family)) {
			return;
		}

		// Add to queue
		self::$queued_fonts[] = $font_family;

		// Register footer hook on first queue
		if (!self::$hook_registered) {
			\add_action('wp_footer', [self::class, 'enqueue_combined_fonts'], 5);
			\add_filter('wp_resource_hints', [self::class, 'add_resource_hints'], 10, 2);
			self::$hook_registered = true;
		}
	}

	/**
	 * Add resource hints for Google Fonts.
	 *
	 * PERFORMANCE OPTIMIZATION: Helps the browser establish a connection
	 * to the Google Fonts domains earlier.
	 *
	 * @since 1.2.1
	 * @param array  $hints   Resource hints.
	 * @param string $relation_type Relation type.
	 * @return array Modified resource hints.
	 */
	public static function add_resource_hints(array $hints, string $relation_type): array
	{
		if ('preconnect' === $relation_type || 'dns-prefetch' === $relation_type) {
			$hints[] = [
				'href'        => 'https://fonts.googleapis.com',
				'crossorigin' => 'anonymous',
			];
			$hints[] = [
				'href'        => 'https://fonts.gstatic.com',
				'crossorigin' => 'anonymous',
			];
		}

		return $hints;
	}

	/**
	 * Enqueue all queued fonts in a single request.
	 *
	 * Called automatically via wp_footer hook.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function enqueue_combined_fonts(): void
	{
		if (empty(self::$queued_fonts)) {
			return;
		}

		// Remove duplicates
		$fonts = \array_unique(self::$queued_fonts);
		$font_families = [];

		foreach ($fonts as $font) {
			$encoded = Fonts::encode_google_font($font);
			if (!empty($encoded)) {
				$font_families[] = 'family=' . $encoded . ':wght@400;700';
			}
		}

		if (empty($font_families)) {
			return;
		}

		// Build combined URL
		$font_url = 'https://fonts.googleapis.com/css2?' . \implode('&', $font_families) . '&display=swap';

		// Allow filtering
		$font_url = \apply_filters('dynos_combined_google_fonts_url', $font_url, $fonts);

		\wp_enqueue_style(
			'dynos-google-fonts-combined',
			\esc_url($font_url),
			[],
			DYNOS_VERSION
		);
	}

	/**
	 * Reset queued fonts (for testing).
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function reset(): void
	{
		self::$queued_fonts = [];
		self::$hook_registered = false;
	}
}
