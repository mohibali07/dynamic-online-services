<?php
/**
 * Options Helper
 *
 * @package Dynamic_Online_Services
 * @subpackage Helpers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Helpers;

use TechmireSolutions\DynamicOnlineServices\Settings\Defaults;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class Options
 *
 * Helper to retrieve plugin options.
 */
class Options
{
	/**
	 * Initialize options helper.
	 *
	 * @return void
	 */
	public static function init(): void
	{
		// Placeholder for future initialization logic
	}
	/**
	 * Get plugin options.
	 *
	 * @return array
	 */
	public static function get(): array
	{
		$defaults = Defaults::get_options();
		$options  = get_option('dynos_options', []);

		if (!is_array($options)) {
			$options = [];
		}

		return wp_parse_args($options, $defaults);
	}
}
