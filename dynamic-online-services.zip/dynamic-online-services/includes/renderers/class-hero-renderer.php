<?php
/**
 * Hero Renderer Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Renderers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Renderers;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;

use TechmireSolutions\DynamicOnlineServices\Helpers\StyleBuilder;

if (!\defined('ABSPATH')) {
	exit;
}

/**
 * Class HeroRenderer
 */
class HeroRenderer extends AbstractRenderer
{

	/**
	 * Constructor.
	 *
	 * @param \TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface $settings_service
	 * @param \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader
	 */
	public function __construct(
		\TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface $settings_service,
		\TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader
	) {
		parent::__construct($template_loader);
		// Note: settings_service is not currently stored as a property in this class,
		// but is passed to the constructor. We keep it for signature compatibility if needed,
		// though it's not used in the existing render method logic (only local variables).
	}

	/**
	 * Render the hero section.
	 *
	 * @param array $data Data for rendering.
	 * @return string HTML output.
	 */
	public function render(array $data): string
	{
		$defaults = [
			'image_url' => '',
			'height' => '50vh',
			'title_color' => '#FFFFFF',
			'font_family' => 'sans-serif',
			'title' => '',
			'description' => '',
			'data_attribute' => '',
			'data_value' => '',
			'breadcrumbs' => '',
		];

		$data = wp_parse_args($data, $defaults);

		// Prep data for template
		$render_data = [
			'image_url' => esc_url($data['image_url']),
			'height' => $data['height'],
			'title_color' => $data['title_color'],
			'font_family' => $data['font_family'],
			'title' => $data['title'], // Escaped in template
			'description' => !empty($data['description']) ? $data['description'] : '', // Sanitized in template
			'data_attribute' => sanitize_key($data['data_attribute']),
			'data_value' => $data['data_value'],
			'breadcrumbs' => $data['breadcrumbs'],
		];

		// Build style attributes
		$render_data['hero_inner_style_value'] = StyleBuilder::build_hero_inner_style($render_data['height'], $render_data['image_url']);
		$render_data['hero_content_style_value'] = StyleBuilder::build_hero_content_style($render_data['title_color'], $render_data['font_family']);

		return $this->template_loader->render('hero', $render_data);
	}
}
