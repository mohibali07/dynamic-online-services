<?php
/**
 * Abstract Renderer Class
 *
 * Base class for all renderers to ensure consistent interface implementation.
 *
 * @package Dynamic_Online_Services
 * @subpackage Renderers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Renderers;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Abstract Class AbstractRenderer
 */
abstract class AbstractRenderer implements RendererInterface
{
	/**
	 * Template Loader.
	 *
	 * @var \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader
	 */
	protected $template_loader;

	/**
	 * Constructor.
	 *
	 * @param \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader
	 */
	public function __construct(\TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader) {
		$this->template_loader = $template_loader;
	}

	/**
	 * Render the component.
	 *
	 * @param array $data Data required for rendering.
	 * @return string HTML output.
	 */
	abstract public function render(array $data): string;
}
