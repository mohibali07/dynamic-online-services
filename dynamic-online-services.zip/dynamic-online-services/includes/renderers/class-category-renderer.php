<?php
/**
 * Category Renderer
 *
 * Handles rendering of category shortcode HTML output.
 *
 * @package Dynamic_Online_Services
 * @subpackage Renderers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Renderers;

use TechmireSolutions\DynamicOnlineServices\Renderers\AbstractRenderer;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization;
use TechmireSolutions\DynamicOnlineServices\Helpers\StyleBuilder;
use WP_Term;

if ( ! \defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Category Renderer class.
 */
class CategoryRenderer extends AbstractRenderer
{
	/**
	 * Settings Service.
	 *
	 * @var \TechmireSolutions\DynamicOnlineServices\Services\SettingsService
	 */
	private $settings_service;

	/**
	 * Post Data Service.
	 *
	 * @var \TechmireSolutions\DynamicOnlineServices\Services\PostDataService
	 */
	private $post_data_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService $settings_service Settings Service.
	 * @param \TechmireSolutions\DynamicOnlineServices\Services\PostDataService $post_data_service Post Data Service.
	 */
	public function __construct(
		?\TechmireSolutions\DynamicOnlineServices\Services\SettingsService $settings_service = null,
		?\TechmireSolutions\DynamicOnlineServices\Services\PostDataService $post_data_service = null,
		?\TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader = null
	) {
		parent::__construct($template_loader ?: new \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader());
		$this->settings_service = $settings_service ?: new \TechmireSolutions\DynamicOnlineServices\Services\SettingsService();
		$this->post_data_service = $post_data_service ?: new \TechmireSolutions\DynamicOnlineServices\Services\PostDataService();
	}

	/**
	 * Render category shortcode items as HTML.
	 *
	 * @since 1.2.0
	 * @param array $data {
	 *     @type array   $items Items to display.
	 *     @type WP_Term $term  Current term object.
	 *     @type array   $atts  Shortcode attributes.
	 * }
	 * @return string HTML output.
	 */
	public function render(array $data): string
	{
		$items = isset($data['items']) ? $data['items'] : [];
		$term = isset($data['term']) ? $data['term'] : null;
		$atts = isset($data['atts']) ? $data['atts'] : [];

		if (empty($items)) {
			$empty_message = apply_filters(
				'dynos_category_content_empty_message',
				__('No services or sub-categories found in this category.', 'dynamic-online-services'),
				$term
			);
			return '<p class="dynos-no-content">' . esc_html($empty_message) . '</p>';
		}

		$grid_min_width = ! empty( $atts['min_width'] ) ? Sanitization::escape_css_value( $atts['min_width'], 'min-width' ) : $this->settings_service->get_option('card_grid_min_width', DYNOS_DEFAULT_GRID_MIN_WIDTH);
		$grid_min_width = Sanitization::escape_css_value( $grid_min_width, 'min-width' );
		if ( empty( $grid_min_width ) ) {
			$grid_min_width = DYNOS_DEFAULT_GRID_MIN_WIDTH;
		}

		$grid_column_gap = $this->settings_service->get_option('card_grid_column_gap', '20px');
		$grid_row_gap    = $this->settings_service->get_option('card_grid_row_gap', '40px');

		$columns = isset($atts['columns']) ? $atts['columns'] : 'auto';
		if ( 'auto' !== $columns && \is_numeric( $columns ) ) {
			$columns = absint( $columns );
			$columns = \min( \max( $columns, DYNOS_MIN_GRID_COLUMNS ), DYNOS_MAX_GRID_COLUMNS );
			$grid_style = 'grid-template-columns: repeat(' . absint( $columns ) . ', 1fr);';
		} else {
			$grid_style = 'grid-template-columns: repeat(auto-fit, minmax(' . $grid_min_width . ', 1fr));';
		}

		$grid_column_gap = Sanitization::escape_css_value( $grid_column_gap, 'width' );
		$grid_row_gap    = Sanitization::escape_css_value( $grid_row_gap, 'height' );
		if ( empty( $grid_column_gap ) ) { $grid_column_gap = '20px'; }
		if ( empty( $grid_row_gap ) ) { $grid_row_gap = '40px'; }

		$grid_style_value = StyleBuilder::build_grid_style(
			[
				'grid_style' => $grid_style,
				'column_gap' => $grid_column_gap,
				'row_gap'    => $grid_row_gap,
			]
		);

		return $this->template_loader->render(
			'cards',
			[
				'items' => $items,
				'atts' => $atts,
				'grid_style_value' => $grid_style_value,
				'renderer' => $this,
			]
		);
	}

	/**
	 * Render a single category shortcode item.
	 *
	 * @since 1.2.0
	 * @param array   $item  Item data.
	 * @param int     $index Item index.
	 * @param WP_Term $term  Current term object.
	 * @return string HTML output for single item.
	 */
	public function render_item( array $item, int $index = 0, ?\WP_Term $term = null ): string {
		$image_url = '';
		$image_alt = '';

		if ( 'post' === $item['type'] ) {
			$image_url = isset( $item['image_url'] ) ? $item['image_url'] : '';
			$image_alt = isset( $item['image_alt'] ) ? $item['image_alt'] : '';
		} elseif ( 'category' === $item['type'] ) {
			if ( ! empty( $item['image_id'] ) ) {
				$attachment_id = absint( $item['image_id'] );
				if ( $attachment_id > 0 && \wp_attachment_is_image( $attachment_id ) ) {
					$attachment_url = \wp_get_attachment_image_url( $attachment_id, 'full' );
					if ( $attachment_url ) {
						$image_url = esc_url( $attachment_url );
						$image_alt = esc_attr( $item['title'] );
					}
				}
			}
		}

		if ( empty( $image_url ) ) {
			$image_url = $this->post_data_service->get_placeholder_url();
			if ( empty( $image_alt ) && isset( $item['title'] ) ) {
				$image_alt = esc_attr( $item['title'] );
			}
		}

		$button_text = apply_filters( 'dynos_category_content_button_text', __( 'VIEW DETAILS', 'dynamic-online-services' ), $item );

		return $this->template_loader->render(
			'card-item',
			[
				'item' => $item,
				'image_url' => $image_url,
				'button_text' => $button_text,
			]
		);
	}
}
