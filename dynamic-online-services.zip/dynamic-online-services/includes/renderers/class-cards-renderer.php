<?php
/**
 * Cards Renderer Class
 *
 * @package Dynamic_Online_Services
 * @subpackage Renderers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Renderers;

use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Services\PostDataService;

if (!\defined('ABSPATH')) {
	exit;
}

/**
 * Class CardsRenderer
 */
class CardsRenderer extends AbstractRenderer
{
	/**
	 * Settings Service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Post Data Service.
	 *
	 * @var PostDataService
	 */
	private $post_data_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService $settings_service
	 * @param PostDataService $post_data_service
	 * @param \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader
	 */
	public function __construct(
		?SettingsService $settings_service = null,
		?PostDataService $post_data_service = null,
		?\TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader = null
	) {
		parent::__construct($template_loader ?: new \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader());
		$this->settings_service = $settings_service ?: new SettingsService();
		$this->post_data_service = $post_data_service ?: new PostDataService();
	}

	/**
	 * Render the cards grid.
	 *
	 * @param array $data {
	 *     @type array $items Items to display.
	 *     @type array $atts Shortcode attributes.
	 * }
	 * @return string HTML output.
	 */
	public function render(array $data): string
	{
		$items = isset($data['items']) ? $data['items'] : [];
		$atts = isset($data['atts']) ? $data['atts'] : [];

		if (empty($items)) {
			return '<!-- DYNOS: No items found for shortcode -->';
		}

		$default_min_width = \defined('DYNOS_DEFAULT_GRID_MIN_WIDTH') ? DYNOS_DEFAULT_GRID_MIN_WIDTH : '280px';
		$min_cols = \defined('DYNOS_MIN_GRID_COLUMNS') ? DYNOS_MIN_GRID_COLUMNS : 1;
		$max_cols = \defined('DYNOS_MAX_GRID_COLUMNS') ? DYNOS_MAX_GRID_COLUMNS : 6;

		$opt_min_width = $this->settings_service->get_option('card_grid_min_width', $default_min_width);
		$grid_min_width = !empty($atts['min_width']) ? $atts['min_width'] : $opt_min_width;
		$grid_min_width = \TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization::escape_css_value($grid_min_width, 'min-width');

		if (empty($grid_min_width)) {
			$grid_min_width = $default_min_width;
		}

		$grid_column_gap = $this->settings_service->get_option('card_grid_column_gap', '20px');
		$grid_row_gap = $this->settings_service->get_option('card_grid_row_gap', '40px');

		$columns = isset($atts['columns']) ? $atts['columns'] : 'auto';
		if ('auto' !== $columns && \is_numeric($columns)) {
			$columns = absint($columns);
			$columns = \min(\max($columns, $min_cols), $max_cols);
			$grid_style = 'grid-template-columns: repeat(' . absint($columns) . ', 1fr);';
		} else {
			$grid_style = 'grid-template-columns: repeat(auto-fit, minmax(' . $grid_min_width . ', 1fr));';
		}

		$grid_column_gap = \TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization::escape_css_value($grid_column_gap, 'width');
		$grid_row_gap = \TechmireSolutions\DynamicOnlineServices\Helpers\Sanitization::escape_css_value($grid_row_gap, 'height');

		$grid_style_value = \TechmireSolutions\DynamicOnlineServices\Helpers\StyleBuilder::build_grid_style(
			[
				'grid_style' => $grid_style,
				'column_gap' => $grid_column_gap,
				'row_gap' => $grid_row_gap,
			]
		);

		return $this->template_loader->render(
			'cards',
			[
				'items' => $items,
				'atts' => $atts,
				'grid_style_value' => $grid_style_value,
				'renderer' => $this,
			]
		);
	}

	/**
	 * Render a single card item.
	 *
	 * @param array $item
	 * @return string
	 */
	public function render_item(array $item): string
	{
		$image_url = !empty($item['image_url']) ? $item['image_url'] : $this->post_data_service->get_placeholder_url();
		$button_text = $this->settings_service->get_option('card_button_text', 'VIEW DETAILS');

		return $this->template_loader->render(
			'card-item',
			[
				'item' => $item,
				'image_url' => $image_url,
				'button_text' => $button_text,
			]
		);
	}
}
