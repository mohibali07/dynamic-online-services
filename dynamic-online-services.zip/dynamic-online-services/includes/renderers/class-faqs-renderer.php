<?php
/**
 * FAQs Renderer
 *
 * Handles rendering of FAQ accordion HTML.
 *
 * @package Dynamic_Online_Services
 * @subpackage Renderers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Renderers;

use TechmireSolutions\DynamicOnlineServices\Styles\FaqStyles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * FaqsRenderer class.
 */
class FaqsRenderer extends AbstractRenderer {

	/**
	 * Constructor.
	 *
	 * @param \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader Template Loader.
	 */
	public function __construct( \TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader $template_loader ) {
		parent::__construct( $template_loader );
	}

	/**
	 * Render data.
	 *
	 * @param array $data Data to render.
	 * @return string HTML output.
	 */
	public function render( array $data ): string {
		$faqs    = isset( $data['faqs'] ) ? $data['faqs'] : [];
		$post_id = isset( $data['post_id'] ) ? (int) $data['post_id'] : 0;
		$title   = isset( $data['title'] ) ? $data['title'] : '';

		// Enqueue accordion scripts and styles using dedicated helper
		if ( class_exists( FaqStyles::class ) ) {
			FaqStyles::enqueue( true );
		}

		// Allow filtering the title
		$title = apply_filters( 'dynos_faqs_title', $title, $post_id );

		// Prepare items for template
		$items = [];
		foreach ( $faqs as $index => $faq ) {
			$question = isset( $faq['question'] ) ? trim( $faq['question'] ) : '';
			$answer   = isset( $faq['answer'] ) ? trim( $faq['answer'] ) : '';

			if ( empty( $question ) ) {
				continue;
			}

			$faq_item = apply_filters(
				'dynos_faq_item',
				[
					'question' => $question,
					'answer'   => $answer,
				],
				$index,
				$post_id
			);

			$items[] = [
				'title'   => $faq_item['question'],
				'content' => $faq_item['answer'],
			];
		}

		if ( empty( $items ) ) {
			return '';
		}

		return $this->template_loader->render( 'faqs', [ 'items' => $items ] );
	}
}
