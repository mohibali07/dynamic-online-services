<?php
/**
 * LiteSpeed Cache Integration
 *
 * @package Dynamic_Online_Services
 * @subpackage Integration
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Integration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * LiteSpeedCache class.
 */
class LiteSpeedCache
{
	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void
	{
		// Hook into settings save to purge cache when global styles/settings change.
		add_action( 'updated_option', [ $this, 'on_option_update' ], 10, 3 );

		add_action( 'dynos_after_save_faqs', [ $this, 'purge_post_cache' ] );
		add_action( 'save_post', [ $this, 'purge_post_cache' ] );
		add_action( 'created_term', [ $this, 'purge_term_cache' ] );
		add_action( 'edited_term', [ $this, 'purge_term_cache' ] );
		add_action( 'delete_term', [ $this, 'purge_term_cache' ] );

		// Add cache tags for better granular purging
		add_filter( 'litespeed_cache_tag_prefix', [ $this, 'add_cache_tag_prefix' ] );
		add_action( 'wp_head', [ $this, 'add_public_cache_tags' ], 1 );
	}

	/**
	 * Handle option updates.
	 *
	 * @param string $option    Option name.
	 * @param mixed  $old_value Old value.
	 * @param mixed  $value     New value.
	 * @return void
	 */
	public function on_option_update( string $option, $old_value, $value ): void
	{
		if ( 'dynos_options' === $option ) {
			$this->purge_all();
		}
	}

	/**
	 * Purge all LiteSpeed Cache.
	 *
	 * @return void
	 */
	private function purge_all(): void
	{
		// Method 1: LiteSpeed Cache Plugin API action
		if ( has_action( 'litespeed_purge_all' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
			do_action( 'litespeed_purge_all' );
			return;
		}

		// Method 2: Check for global function if action not available (older versions or direct call)
		if ( function_exists( 'litespeed_purge_all' ) ) {
			litespeed_purge_all();
		}
	}

	/**
	 * Purge post cache when post is saved.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function purge_post_cache( int $post_id ): void
	{
		if ( function_exists( 'do_action' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
			do_action( 'litespeed_purge_post', $post_id );
		}
	}

	/**
	 * Purge term cache.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	public function purge_term_cache( int $term_id ): void
	{
		if ( function_exists( 'do_action' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
			do_action( 'litespeed_purge_all' );
		}
	}

	/**
	 * Add cache tag prefix for plugin-specific tags.
	 *
	 * @param string $prefix Current prefix.
	 * @return string Modified prefix.
	 */
	public function add_cache_tag_prefix( string $prefix ): string
	{
		return $prefix . '.dynos';
	}

	/**
	 * Add public cache tags for better granular purging.
	 * Allows purging specific service or category pages without full purge.
	 *
	 * @return void
	 */
	public function add_public_cache_tags(): void
	{
		if ( ! function_exists( 'do_action' ) ) {
			return;
		}

		// Add tag for service post type pages
		if ( is_singular( 'service' ) ) {
			$post_id = get_the_ID();
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
			do_action( 'litespeed_tag_add', 'dynos_service_' . $post_id );
		}

		// Add tag for service category archive pages
		if ( is_tax( 'service-category' ) ) {
			$term = get_queried_object();
			if ( $term && isset( $term->term_id ) ) {
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
				do_action( 'litespeed_tag_add', 'dynos_cat_' . $term->term_id );
			}
		}

		// Add general tag for all plugin pages
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Third-party LiteSpeed Cache hook
		do_action( 'litespeed_tag_add', 'dynos_all' );
	}
}
