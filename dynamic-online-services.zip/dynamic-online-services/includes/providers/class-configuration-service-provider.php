<?php
/**
 * Configuration Service Provider
 *
 * Registers and boots the configuration service.
 *
 * @package Dynamic_Online_Services
 * @subpackage Providers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Providers;

use TechmireSolutions\DynamicOnlineServices\Core\Container;
use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Services\ConfigurationService;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class ConfigurationServiceProvider
 */
class ConfigurationServiceProvider implements ServiceProviderInterface
{
	/**
	 * The container instance.
	 *
	 * @var Container
	 */
	private $container;

	/**
	 * Constructor.
	 *
	 * @param Container $container Dependency injection container.
	 */
	public function __construct(Container $container)
	{
		$this->container = $container;
	}

	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		// Register ConfigurationService as singleton
		$this->container->set(
			ConfigurationService::class,
			function () {
				return new ConfigurationService();
			},
			true // Shared/Singleton
		);
	}

	/**
	 * Bootstrap services.
	 *
	 * Defines plugin constants using the ConfigurationService.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		/** @var ConfigurationService $config */
		$config = $this->container->get(ConfigurationService::class);

		// Define all configuration constants
		$config->define_constants();
	}
}
