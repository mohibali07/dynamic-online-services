<?php
/**
 * Shortcode Service Provider
 *
 * Registers and boots all shortcodes.
 *
 * @package Dynamic_Online_Services
 * @subpackage Providers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Providers;

use TechmireSolutions\DynamicOnlineServices\Core\Container;
use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\RendererInterface;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\ShortcodeManager;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\CategoryHero;
use TechmireSolutions\DynamicOnlineServices\Shortcodes\ServiceHero;
use TechmireSolutions\DynamicOnlineServices\Services\HeroDataService;
use TechmireSolutions\DynamicOnlineServices\Services\StyleService;
use TechmireSolutions\DynamicOnlineServices\Renderers\HeroRenderer;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class ShortcodeServiceProvider
 */
class ShortcodeServiceProvider implements ServiceProviderInterface
{
	/**
	 * The container instance.
	 *
	 * @var Container
	 */
	private $container;

	/**
	 * Constructor.
	 *
	 * @param Container $container Dependency injection container.
	 */
	public function __construct(Container $container)
	{
		$this->container = $container;
	}

	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		// Register ShortcodeManager
		$this->container->set(
			ShortcodeManager::class,
			function () {
				return new ShortcodeManager();
			},
			true
		);

		// Register HeroRenderer
		$this->container->set(
			HeroRenderer::class,
			function ($container) {
				return new HeroRenderer(
					$container->get(SettingsServiceInterface::class),
					$container->get(\TechmireSolutions\DynamicOnlineServices\Core\TemplateLoader::class)
				);
			},
			true
		);

		// Register CategoryHero Shortcode
		$this->container->set(
			CategoryHero::class,
			function ($container) {
				return new CategoryHero(
					$container->get(SettingsServiceInterface::class),
					$container->get(HeroRenderer::class),
					$container->get(StyleService::class),
					$container->get(HeroDataService::class)
				);
			},
			false // Transient - create new instance each time
		);

		// Register ServiceHero Shortcode
		$this->container->set(
			ServiceHero::class,
			function ($container) {
				return new ServiceHero(
					$container->get(SettingsServiceInterface::class),
					$container->get(HeroRenderer::class),
					$container->get(StyleService::class),
					$container->get(HeroDataService::class)
				);
			},
			false // Transient
		);
	}

	/**
	 * Bootstrap services.
	 *
	 * Registers all shortcodes with WordPress.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		/** @var ShortcodeManager $manager */
		$manager = $this->container->get(ShortcodeManager::class);

		// Register shortcodes
		$manager->register($this->container->get(CategoryHero::class));
		$manager->register($this->container->get(ServiceHero::class));

		// Boot the shortcode manager (registers with WordPress)
		$manager->boot();
	}
}
