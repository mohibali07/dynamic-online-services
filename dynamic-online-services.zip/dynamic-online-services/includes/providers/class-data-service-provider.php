<?php
/**
 * Data Service Provider
 *
 * Registers all data-related services including settings, post data, admin notices, and CPT settings.
 *
 * @package Dynamic_Online_Services
 * @subpackage Providers
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Providers;

use TechmireSolutions\DynamicOnlineServices\Core\Container;
use TechmireSolutions\DynamicOnlineServices\Interfaces\ServiceProviderInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\SettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\PostDataServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\AdminNoticeServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Interfaces\CptSettingsServiceInterface;
use TechmireSolutions\DynamicOnlineServices\Services\SettingsService;
use TechmireSolutions\DynamicOnlineServices\Services\PostDataService;
use TechmireSolutions\DynamicOnlineServices\Services\AdminNoticeService;
use TechmireSolutions\DynamicOnlineServices\Services\StyleService;
use TechmireSolutions\DynamicOnlineServices\Services\HeroDataService;
use TechmireSolutions\DynamicOnlineServices\PostTypes\CptSettingsValidator;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Class DataServiceProvider
 */
class DataServiceProvider implements ServiceProviderInterface
{
	/**
	 * The container instance.
	 *
	 * @var Container
	 */
	private $container;

	/**
	 * Constructor.
	 *
	 * @param Container $container Dependency injection container.
	 */
	public function __construct(Container $container)
	{
		$this->container = $container;
	}

	/**
	 * Register services.
	 *
	 * @return void
	 */
	public function register(): void
	{
		// Register AdminNoticeService
		$this->container->set(
			AdminNoticeService::class,
			function () {
				return new AdminNoticeService();
			},
			true
		);
		$this->container->set(
			AdminNoticeServiceInterface::class,
			fn($container) => $container->get(AdminNoticeService::class),
			true
		);

		// Register SettingsService
		$this->container->set(
			SettingsService::class,
			function () {
				return new SettingsService();
			},
			true
		);
		$this->container->set(
			SettingsServiceInterface::class,
			fn($container) => $container->get(SettingsService::class),
			true
		);

		// Register PostDataService
		$this->container->set(
			PostDataService::class,
			function () {
				return new PostDataService();
			},
			true
		);
		$this->container->set(
			PostDataServiceInterface::class,
			fn($container) => $container->get(PostDataService::class),
			true
		);

		// Register CptSettingsValidator as CptSettingsServiceInterface
		$this->container->set(
			CptSettingsValidator::class,
			function ($container) {
				return new CptSettingsValidator(
					$container->get(SettingsServiceInterface::class),
					$container->get(AdminNoticeServiceInterface::class)
				);
			},
			true
		);
		$this->container->set(
			CptSettingsServiceInterface::class,
			fn($container) => $container->get(CptSettingsValidator::class),
			true
		);

		// Register StyleService
		$this->container->set(
			StyleService::class,
			function () {
				return new StyleService();
			},
			true
		);

		// Register HeroDataService
		$this->container->set(
			HeroDataService::class,
			function ($container) {
				return new HeroDataService(
					$container->get(SettingsServiceInterface::class),
					$container->get(PostDataServiceInterface::class),
					$container->get(CptSettingsServiceInterface::class)
				);
			},
			true
		);
	}

	/**
	 * Bootstrap services.
	 *
	 * @return void
	 */
	public function boot(): void
	{
		// Data services don't need bootstrapping - they're used on-demand
	}
}
