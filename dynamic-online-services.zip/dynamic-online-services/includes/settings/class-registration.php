<?php
/**
 * Settings Registration
 *
 * Handles registration of plugin settings, sections, and fields.
 *
 * @package Dynamic_Online_Services
 * @subpackage Settings
 */

declare(strict_types=1);

namespace TechmireSolutions\DynamicOnlineServices\Settings;

if ( ! \defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Registration
 */
class Registration {

	/**
	 * Initialize settings registration.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init(): void {
		\add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
	}

	/**
	 * Register settings.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register_settings(): void {
		// NOTE: The actual register_setting() call is now handled by SettingsApiProvider
		// to ensure proper REST API exposure with show_in_rest configuration.
		// We only register sections and fields here for the traditional settings API.

        // Get map from Config
        $map = Config::get_map();

        foreach ($map as $key => $section) {
            // Register Section
            \add_settings_section(
                $section['id'],
                $section['title'],
                '__return_null', // Section callback (description)
                'Dynamic_Online_Services'
            );

            // Register Fields
            Section::register($key);
        }
	}
}
